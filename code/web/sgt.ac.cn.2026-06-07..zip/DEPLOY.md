# SGT 官网部署说明

## 生产环境上传范围

上传 **仓库根目录** 下列内容即可（与 `sgt.ac.cn` 站点根对应）：

- `index.html`、`ai.html`、`*.html`（根目录各内容页）
- `css/`（含 `style.css`、`sgt-tutor.css`、`sgt-ai-page.css`）
- `js/`（含 `sgt-app.js` 及 AI 模块：`sgt-ai-store.js`、`sgt-ai-engine.js`、`sgt-tutor-md.js`、`sgt-tutor.js`、`sgt-ai-page.js`）
- `assets/`（含 `og-sgt.png`、`favicon.ico`、`sgt-icon.png`）
- `solver/`（含 `index.html`、思想实验页、`js/solver-app.js`）
- `robots.txt`、`sitemap.xml`

## 切勿上传

| 路径 | 说明 |
|------|------|
| **`1/`** | 临时目录，**不上生产** |
| `scripts/`、`partials/` | 本地维护用，可选 |
| `TECHNICAL.md`、`DEPLOY.md` | 文档，可选 |

`robots.txt` 已包含 `Disallow: /1/`。

## 改导航 / 页脚

**默认：直接编辑各 HTML 文件**（页内已有完整页头页脚）。

若使用 `partials/` 统一改了一版，可在 Windows 上执行一次同步（可选）：

```powershell
powershell -File scripts/build-site.ps1
```

## Nginx 反代

**Solver API：**

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:8716/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

**SGT AI 精灵（`/chat`，端口按实际后端调整）：**

```nginx
location /chat {
    proxy_pass http://127.0.0.1:<CHAT_PORT>/chat;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_buffering off;
    proxy_read_timeout 120s;
}
```

前端一律请求同源 `/api/...` 与 `/chat`，避免 CORS。

## 上线检查

- [ ] `https://sgt.ac.cn/assets/og-sgt.png` 可访问
- [ ] `https://sgt.ac.cn/ai.html` 可打开，对话与归档正常
- [ ] `https://sgt.ac.cn/sitemap.xml`
- [ ] `GET /api/health` → `{"status":"ok"}`
- [ ] `POST /chat` 可返回 AI 回复（浮窗或 AI 页试一条）
- [ ] 根目录无 `1/` 文件夹

详细说明见 `TECHNICAL.md` §4.1、§10。
