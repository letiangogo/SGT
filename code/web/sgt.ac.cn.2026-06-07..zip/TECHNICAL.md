# SGT 官网与 Solver 技术文档

> **读者：** 未来维护者、协作者或 AI 助手。阅读本文应能独立理解仓库结构、部署方式、前后端契约与常见改动路径。  
> **站点：** https://sgt.ac.cn  
> **仓库根目录：** `D:\SGT\`（生产以根目录为准）  
> **最后更新：** 2026-06-06

---

## 0. 一分钟速览

| 维度 | 说明 |
|------|------|
| **项目性质** | SGT（空能引力理论）双语学术官网 + 数值求解器前端 + Canvas 思想实验 |
| **技术栈** | 纯静态 HTML / CSS / 原生 JavaScript（ES5 风格 IIFE），**无** Webpack / npm 构建 |
| **后端** | `SGT Solver API` 独立服务，默认 `127.0.0.1:8716`，Nginx 反代为同源 `/api/` |
| **版本锚点** | 旗舰论文 SGT-PAPER-012 V1.3 · 宪法基准 V3.9.0 · Solver UI v0.3.1 |
| **部署** | 上传静态文件到 Web 根；**禁止**上传 `1/`、`scripts/`（可选） |
| **相关文档** | `DEPLOY.md`（上线清单精简版） |

### 0.1 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│  浏览器                                                          │
├─────────────────────────────────────────────────────────────────┤
│  主站 (index, paper, framework, ai, …)                           │
│    css/style.css  js/lang.js  js/main.js  js/effects.js         │
│    js/sgt-app.js → 全站注入 AI 精灵浮窗（ai.html 除外）          │
│    js/api-status.js（页脚 API 状态）                              │
├─────────────────────────────────────────────────────────────────┤
│  AI 工作台 ai.html                                               │
│    css/sgt-ai-page.css + sgt-tutor.css                          │
│    sgt-ai-store / sgt-ai-engine / sgt-tutor-md / sgt-ai-page    │
├─────────────────────────────────────────────────────────────────┤
│  Solver 子站 (/solver/)                                          │
│    index.html（内联 CSS + 度规计算器 + Tab 工具）                 │
│    js/metric-calc.js  ← 默认首页工具                             │
│    js/solver-app.js   ← Blackhole/Orbit/Gravity/CH + Token      │
│    rubber-*.html（思想实验，独立页面）                              │
├─────────────────────────────────────────────────────────────────┤
│  外部：Google Fonts · DOI 链接 · 预印本 PDF                       │
└───────────────────────────┬─────────────────────────────────────┘
                            │ POST/GET 同源 /api/*
                            │ POST      同源 /chat
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  SGT Solver API（不在本仓库）  :8716                              │
│  SGT Chat API（不在本仓库）  /chat 反代                           │
└─────────────────────────────────────────────────────────────────┘
```

### 0.2 设计原则

1. **学术主线与工具分离：** 主站顶栏 8 项为理论内容；Solver、ZKAV、思想实验通过 Hero / 论文 / ZKAV 二级入口导流。
2. **双语并列块：** 不用 i18n 框架，HTML 内中英双份内容 + `lang.js` 切换显示。
3. **Solver 子站自包含样式：** 不引用主站 `style.css`，便于 `/solver/` 子路径独立部署。
4. **敏感参数脱敏：** 独立参数 K、f_c 的**数值**不在公开页面展示（见 §12）。
5. **API 失败可降级：** Blackhole 类工具在 API 不可用时使用 Ω-A1 客户端常数回退，并提示用户。

---

## 1. 目录结构

```
SGT/
├── index.html                 # 首页：Hero、指标条、ZKAV spotlight、演化链
├── paper.html                 # 论文总览 / 旗舰论文摘要
├── framework.html             # 理论框架（含关键参数表 §1.4）
├── integrity.html             # 理论纯洁性
├── predictions.html           # 可检验物理预言
├── audit.html                 # 36 项理论体检
├── outlook.html               # 发展路线图
├── copyright.html             # 权属与备案
├── author.html                # 作者简介
├── ai.html                    # SGT AI 精灵全屏工作台（无浮窗）
├── zkav.html                  # 零知识学术验证 ZKAV 协议
│
├── css/
│   ├── style.css              # 主站全局样式（~1100 行）
│   ├── sgt-tutor.css          # AI 精灵浮窗 + Markdown 气泡样式
│   └── sgt-ai-page.css        # ai.html 浅色工作台布局
├── js/
│   ├── lang.js                # 双语切换（全站共用）
│   ├── main.js                # 移动端导航 #site-nav 折叠
│   ├── effects.js             # 首页 Canvas 粒子、滚动显现、ticker
│   ├── api-status.js          # 主站页脚 Solver API 健康徽章
│   ├── sgt-app.js             # 全站调度：注入 AI 浮窗、按需加载 CDN/模块
│   ├── sgt-ai-store.js        # 对话 localStorage（当前 + 临时归档）
│   ├── sgt-ai-engine.js       # 共享对话引擎（API、流式、渲染、复制原文）
│   ├── sgt-tutor-md.js        # AI 回复 Markdown 预处理 + marked + KaTeX
│   ├── sgt-tutor.js           # 浮窗 UI 壳（依赖 store + engine）
│   └── sgt-ai-page.js         # ai.html 专题页（侧栏归档、只读查看）
│
├── assets/                    # favicon、sgt-icon.png、og-sgt.png（部署时需存在）
├── partials/                  # 页头/页脚模板（可选 build 同步）
│   ├── site-header.html
│   ├── site-footer.html
│   ├── sgt-tutor.html         # 浮窗说明（实际由 sgt-app.js 注入，勿手贴）
│   └── README.txt
├── scripts/
│   ├── build-site.ps1         # partials → 各 HTML 同步
│   └── make_icon.py           # 图标生成（本地工具）
│
├── solver/
│   ├── index.html             # Solver 主页（度规计算器 + 更多工具 Tab）
│   ├── js/
│   │   ├── metric-calc.js     # 黑洞度规计算器（默认着陆工具）
│   │   └── solver-app.js      # 经典 Tab 求解器 + CH + Token
│   ├── rubber-room.html       # 思想实验① 橡皮筋房间（静态引力）
│   ├── rubber-band-wave.html  # 思想实验② 皮筋抖动（引力波类比）
│   ├── rubber-band-shake.html # 思想实验③ 水平皮筋（慢直快波）
│   └── demo-canvas.css        # 演示页共用片段（若引用）
│
├── robots.txt                 # Disallow: /1/
├── sitemap.xml
├── DEPLOY.md                  # 部署速查
├── TECHNICAL.md               # 本文档
│
└── 1/                         # ⚠ 历史备份镜像，结构与根目录类似
                               # robots 已 Disallow，禁止上生产
```

---

## 2. 页面地图与导航

### 2.1 主站顶栏（`partials/site-header.html` → 各页 `site-nav`）

**顶栏主链**（ deliberately 不含 ZKAV、Solver、思想实验；共 9 项，含 `ai.html`）：

| 路由 | 中文 | 英文 |
|------|------|------|
| `/index.html` | 首页 | Home |
| `/paper.html` | 论文总览 | Papers |
| `/framework.html` | 理论框架 | Framework |
| `/ai.html` | AI 精灵 | AI |
| `/integrity.html` | 理论纯洁性 | Purity |
| `/predictions.html` | 可检验预言 | Tests |
| `/audit.html` | 理论体检 | Audit |
| `/outlook.html` | 未来展望 | Outlook |
| `/copyright.html` | 权属 | Rights |

`author.html` 在页脚链出，不在顶栏。

### 2.2 二级入口

| 路由 | 主要入口 |
|------|----------|
| `/ai.html` | 顶栏「AI 精灵」、浮窗「全屏工作台」链接 |
| `/zkav.html` | 首页 Hero、ZKAV spotlight、`copyright.html` |
| `/solver/` | 首页 Hero、`zkav.html` |
| `/solver/rubber-room.html` | Solver 顶栏、`paper.html` 思想实验一 |
| `/solver/rubber-band-wave.html` | Solver 顶栏、`paper.html` 思想实验二 |
| `/solver/rubber-band-shake.html` | Solver 顶栏/简介 |

思想实验**刻意**不在首页 Hero 直接链接，仅从 Solver / 论文进入。

### 2.3 Solver 页内结构（`solver/index.html`）

自上而下：

1. **顶栏** `solver-topbar`：回主站、ZKAV、论文、预言、三个思想实验、双语切换
2. **Hero** `solver-hero`：简介 + API 状态（`#api-status-zh/en`）
3. **黑洞度规计算器** `#metric-calculator`（**默认着陆工具**，见 §7）
4. **更多求解工具** `solver-tabs`：Blackhole · Orbit · Gravity · CH 系列
5. **测试码面板** `token-panel`
6. **页脚** + 精度声明模态框 `#modal-precision`

### 2.4 页脚与标识（多数内容页）

- ORCID：`0009-0004-8456-7107`
- 旗舰预印本 DOI：`10.33774/coe-2026-jg7wz`
- TSA · DCI → `copyright.html`
- 作者简介 → `author.html`
- 主站部分页面含 `[data-api-pill]`（`api-status.js` 填充 Solver API 在线状态）

---

## 3. 双语系统（`js/lang.js`）

### 3.1 HTML 标记

```html
<html class="lang-zh">   <!-- 或 lang-en -->
<p class="lang-zh">中文内容</p>
<p class="lang-en">English content</p>
```

Solver / 思想实验页同样引用 `../js/lang.js`，顶栏独立 `[data-lang="zh|en"]` 按钮。

### 3.2 CSS 显示规则（`css/style.css` 与 Solver 内联样式）

```css
html.lang-en .lang-zh { display: none !important; }
html.lang-zh .lang-en { display: none !important; }
```

**致命陷阱：** 禁止写裸 `.lang-en { display: none }`，会命中 `<html class="lang-en">` 导致整页白屏。思想实验页曾踩坑，已统一改为限定父级选择器。

### 3.3 持久化与标题

| 键 | 值 |
|----|-----|
| `localStorage['sgt-lang']` | `'zh'` \| `'en'` |

- `<title data-title-zh="..." data-title-en="...">` 切换时更新 `document.title`
- URL `?lang=en` 可覆盖并写入 localStorage
- `applyLangA11y()` 同步 `hidden` + `aria-hidden`

### 3.4 脚本内 i18n

- `solver-app.js`：`I18N` 对象 + `t(key, vars)`
- `metric-calc.js`：独立 `I18N` + `ERR_MAP`（与 `lang.js` 的 HTML 切换并存）

---

## 4. 主站前端脚本

| 文件 | 加载范围 | 职责 |
|------|----------|------|
| `lang.js` | 全站含 Solver、思想实验 | 双语切换 |
| `main.js` | 主站各内容页 | `#site-nav` 移动端 `.open` |
| `effects.js` | 主站各内容页 + 首页 | `#gravity-canvas` 粒子背景；`.reveal` 滚动动画；`.hero-ticker` 物理参数滚动条；`prefers-reduced-motion` 时跳过动画 |
| `api-status.js` | 带 `[data-api-pill]` 的页脚 | `GET /api/health` → 在线/不可用徽章 |

### 4.1 SGT AI 精灵（全站 + `ai.html`）

#### 4.1.1 模块职责

| 文件 | 职责 |
|------|------|
| `js/sgt-app.js` | 全站 `<script>` 入口；除 `ai.html` 外自动注入浮窗 DOM、加载 marked/KaTeX 与各 AI 模块 |
| `js/sgt-tutor.js` | 浮窗开合、Esc 关闭、「归档并开始新话题」、与 store 同步 |
| `js/sgt-ai-engine.js` | **共享对话引擎**：`POST /chat`、流式/非流式解析、6 轮/500 字限制、Markdown 渲染、**复制原文** |
| `js/sgt-ai-store.js` | `localStorage` 持久化（当前对话 + 临时归档，不上云） |
| `js/sgt-tutor-md.js` | AI 回复 Markdown 预处理 → **marked 12 (GFM)** → KaTeX |
| `js/sgt-ai-page.js` | `ai.html` 侧栏归档、只读查看历史、浅色工作台 UI |
| `css/sgt-tutor.css` | 浮窗深色主题 + 助手气泡 Markdown 样式 |
| `css/sgt-ai-page.css` | `ai.html` 白底布局，覆盖气泡/按钮为浅色 |

#### 4.1.2 两种 UI 形态

| 形态 | 页面 | 说明 |
|------|------|------|
| **浮窗** | 除 `ai.html` 外所有含 `sgt-app.js` 的页 | 右下角 FAB → 面板 ~400px；可链至全屏工作台 |
| **工作台** | `ai.html` | 无 FAB；左侧归档列表 + 主对话区；`<script src="js/sgt-app.js" data-ai="false">` 禁止二次注入浮窗 |

浮窗与工作台**共用** `sgt_ai_genie_v1` 中的当前对话；重置/归档行为一致。

#### 4.1.3 API 与限额

| 项 | 说明 |
|----|------|
| 端点 | `POST /chat`，body：`{"message": "<buildContext 输出>"}` |
| 响应 | JSON `{ reply, sources }` 或 SSE / NDJSON / 纯文本流 |
| 超时 | 60 秒 |
| 上下文 | 最近 6 轮（12 条消息）压缩为 `[前情]…[/前情][当前问题]…` 再发送；界面仍展示用户原始输入 |
| 轮次上限 | 每段对话最多 **6 轮**问答；第 7 轮自动新话题（可选归档旧对话） |
| 输入上限 | 单条最多 **500 字**（`maxlength` + 引擎校验 + 字数计数器） |
| 流式渲染 | 防抖 ~**120ms**（`STREAM_RENDER_MS`）；结束后最终 Markdown 渲染 |

**部署：** Nginx 需将 `/chat` 反代至对话后端（与 `/api/` 可同机不同路径）。

#### 4.1.4 本地持久化（`sgt-ai-store.js`）

| 键 | 内容 |
|----|------|
| `localStorage['sgt_ai_genie_v1']` | 当前对话 `{ messages[], isOpen, ts }`；最多保留最近 12 条 |
| `localStorage['sgt_ai_genie_archives_v1']` | 临时归档列表，最多 **50** 条；标题取首条用户问题前 40 字 |

- 浮窗「新话题」/ 工作台「归档并开始新对话」：旧对话写入归档，当前清空。
- 归档仅在浏览器本地；换设备/清缓存即丢失。
- 查看归档时为**只读**模式（隐藏输入框）。

#### 4.1.5 Markdown 渲染管线（`sgt-tutor-md.js`）

依赖 CDN：**marked@12.0.2**（GFM）、**KaTeX@0.16.11**（可选降级为纯文本）。

`normalizeMarkdown()` 处理顺序（**勿随意调换**，后步依赖前步换行）：

1. 转义 `\n`、删 pipe 垃圾行（`| :`）
2. **`repairCompactMarkdown`** — AI 常把整段挤成一行；中/英规则恢复 `###`、`-` 列表、`---`、`**标题:**`、有序列表 `1.` 等
3. **`repairCompactPipeTables`** — 单行 `||` 分隔的 pipe 表
4. **`repairMultiLineTabTables`** — Tab 分隔多行表（默认 4 列，`对比维度` 等表头）
5. **`repairPipeTables`** — Tab 表头 + `\|\|` 行混排
6. 短标题行 `标题：正文` → `### 标题`（2–14 字标题）
7. 合并多余空行

`render()` = `normalize` → 抽取 `$…$` / `$$…$$` → `marked.parse` → KaTeX → 表格外包 `.sgt-md-table-wrap`。

**调试：** 助手回复完成后点 **「复制原文 / Copy raw」**，粘贴到编辑器对比 API 原始 Markdown 与页面渲染差异；若有 `sources` 则文末追加 `---` 与来源列表。

#### 4.1.6 脚本加载顺序

**浮窗（由 `sgt-app.js` 动态加载）：**

```
sgt-ai-store.js → marked → katex → sgt-tutor-md.js → sgt-ai-engine.js → sgt-tutor.js
```

**`ai.html`（静态引用）：**

```
marked → katex → sgt-tutor-md.js → sgt-ai-store.js → sgt-ai-engine.js → sgt-ai-page.js
→ api-status.js → main.js → sgt-app.js (data-ai="false")
```

**Solver / 思想实验：** `../js/sgt-app.js`，浮窗 base 路径自动为 `../`。

#### 4.1.7 扩展入口

```javascript
// 禁用某页浮窗（如 ai.html）
<script src="js/sgt-app.js" data-ai="false"></script>

// 编程式创建对话（见 sgt-ai-engine.js）
SgtAiEngine.create({ messagesEl, inputEl, … });
```

### 4.2 首页 ticker（`effects.js`）

滚动展示公开物理常数。**K、f_c 已脱敏为 `--`**，其余示例：

- `r_H = 1.6673 M`、`ISCO = 4.23 M`、`T_H = 0.866 T_H^GR`、`H(0) = 1.023×10⁻¹` 等

---

## 5. 主站样式（`css/style.css`）

- **字体：** Google Fonts — `Noto Serif SC`（中文标题）、`Source Serif 4`（英文）
- **主题：** 深色学术风；强调色 `#00d4ff`
- **关键组件：** `.site-header`、`.hero-home`、`.metrics-strip`、`.advantage-grid`、`.academic-table`、`.zkav-spotlight`、`.roadmap-step`、`.compare-visual` 等
- **首页层级：** `effects.js` 向 `body` 前置 `#gravity-canvas`，内容区 z-index 保证可读

---

## 6. 导航/页脚批量维护

### 6.1 日常方式

直接编辑各 HTML 中的页头页脚（多数页面已内嵌完整片段）。

### 6.2 partials 同步（可选）

标记块：

```html
<!-- sgt:site-header -->
…
<!-- /sgt:site-header -->
```

Windows 执行：

```powershell
powershell -File scripts/build-site.ps1
```

同步页面：`index.html`、`ai.html`、`paper.html`、`framework.html`、`integrity.html`、`predictions.html`、`audit.html`、`outlook.html`、`copyright.html`、`author.html`、`zkav.html`。

`{{ACTIVE_index.html}}` 等占位符由脚本替换为 `class="active"`。

---

## 7. SGT Solver 详解

**入口：** `https://sgt.ac.cn/solver/` → `solver/index.html`

**脚本加载顺序：**

```html
<script src="../js/lang.js"></script>
<script src="js/metric-calc.js"></script>
<script src="js/solver-app.js"></script>
```

### 7.1 全局配置（`solver-app.js`）

```javascript
var API_BASE = '/api';
var API_VERSION = '0.3.1';
var TOKEN_KEY = 'sgt_api_token';   // localStorage
var TIMEOUT_MS = 10000;
var R_H_PER_M = 1.6673;

var SGT_BH = { r_h: 1.6673, r_ph: 2.9954, isco: 4.23, t_coeff: 0.866 };
var GR_BH  = { r_h: 2,      r_ph: 3,      isco: 6,    t_coeff: 1 };
```

### 7.2 API 端点总表

| 方法 | 路径 | Token | 请求体 | 说明 |
|------|------|-------|--------|------|
| GET | `/api/health` | 否 | — | `{ "status": "ok", "version": "0.3.1" }` |
| GET | `/api/token_info?token=…` | — | — | 仅 HTTP **200** 有效；含 `remaining`/`max` |
| POST | `/api/blackhole` | 否 | `{ "M", "a"? }` | 黑洞参数；见 §7.3 双格式 |
| POST | `/api/orbit` | 是 | `{ "M", "r" }` | r 单位 km |
| POST | `/api/gravity` | 是 | `{ "M", "r" }` | r 单位 km |
| GET | `/api/ch/hierarchy` | 否 | — | CH 层级表 |
| POST | `/api/ch/analyze` | Kerr 时需 | `{ background, structure, eps, a_star }` | 稳定性分析 |
| POST | `/api/ch/custom` | 是 | `{ alpha, beta }` | 自定义扰动 |

**Token 请求头：** `X-API-Token: <token>`，`Content-Type: application/json`

**错误解析：** `getApiErrorMessage()` 优先 `error`，其次 `detail`。

---

### 7.3 黑洞度规计算器（`metric-calc.js`）★ 默认工具

#### 7.3.1 职责

- 页面首屏：输入质量 M（M☉）、自旋 a∈[0,0.9]
- 调用 `POST /api/blackhole`
- 展示 SGT vs GR 对比表（ISCO、光子球、视界、T_H 比）
- r 滑块（ISCO → 20M）实时显示 g、v 及差异
- 「在此半径对比」将当前 r 的 g、v 追加进表格
- 若 API 返回 `r_grid` + `g_SGT`/`g_GR`，绘制 g(r) Canvas 曲线

#### 7.3.2 DOM ID 约定

| ID | 用途 |
|----|------|
| `mc-mass`, `mc-spin` | 输入 |
| `mc-err-m`, `mc-err-a` | 字段级校验错误 |
| `mc-btn-calc` | 计算按钮 |
| `mc-slider`, `mc-slider-wrap` | 半径滑块（计算后启用） |
| `mc-table-body` | 对比表 tbody |
| `mc-detail`, `mc-g-sgt`, `mc-v-dev` 等 | 径向详情 |
| `mc-chart` | g(r) 曲线 |
| `mc-global-err`, `mc-api-note` | 全局错误 / 回退提示 |

#### 7.3.3 新 API 响应格式（推荐，后端目标契约）

**请求：**

```json
{ "M": 10.0, "a": 0.3 }
```

**成功 200：**

```json
{
  "status": "success",
  "M": 10.0,
  "a": 0.3,
  "r_H": 1.668,
  "r_ph": 2.995,
  "r_ISCO_SGT": 4.230,
  "r_ISCO_GR": 6.000,
  "T_H_ratio": 0.866,
  "r_grid": [4.0, 5.0, 6.0, 8.0, 10.0],
  "g_SGT": [ … ],
  "g_GR":  [ … ],
  "v_SGT": [ … ],
  "v_GR":  [ … ]
}
```

量均为 **无量纲 r/M** 或相对比值（T_H_ratio = SGT/GR）。

**错误 4xx/5xx：**

```json
{
  "status": "error",
  "error_code": "INVALID_A",
  "message": "a must be in [0, 0.9]"
}
```

| error_code | 中文提示（前端映射） |
|------------|---------------------|
| `INVALID_M` | 质量必须为正数 |
| `INVALID_A` | 自旋参数必须在 0 到 0.9 之间 |
| `MISSING_M` | 请输入质量 |
| `SOLVER_FAILED` | 求解器未收敛，请调整参数后重试 |
| `INTERNAL` | 服务器内部错误，请稍后重试 |

#### 7.3.4 旧 API 响应格式（`solver-app.js` 仍在用）

```json
{
  "SGT": { "r_H_m": …, "r_ph_m": …, "r_ISCO_m": …, "T_H_ratio": … },
  "GR":  { … },
  "deviation_percent": { … }
}
```

`metric-calc.js` 的 `fromLegacy()` 检测到 `SGT`/`sgt` 键时，用 `FALLBACK` 常数填充度规表（因旧接口以 km 输出、且无 a 自旋字段）。

#### 7.3.5 客户端回退（`FALLBACK`）

API 失败、网络错误或简版响应时：

```javascript
{ r_H: 1.6673, r_ph: 2.9954, r_ISCO_SGT: 4.23, r_ISCO_GR: 6.0, T_H_ratio: 0.866 }
```

无 `r_grid` 时，径向 g、v 用 Schwarzschild 近似 + 视界比缩放（`clientG` / `clientV`），并显示 `mc-api-note` 提示。

#### 7.3.6 视觉规范

| 元素 | 值 |
|------|-----|
| 面板背景 | `rgba(22, 33, 62, 0.95)` / `#16213e` |
| 页面底 | `#1a1a2e` |
| 差异 >10% 高亮 | `#D4A017`（金色），表格行 `.mc-row-gold` |
| SGT 数值色 | `#00d4ff` |
| GR 数值色 | `#8888a0` |

#### 7.3.7 度规计算器 URL 参数

| 参数 | 示例 | 作用 |
|------|------|------|
| `M` | `?M=10` | 预填质量（同步 `mc-mass` 与 Tab 内质量框） |
| `a` | `?a=0.3` | 预填自旋 |
| `run=1` 或 `compute=1` | `?M=10&run=1` | 自动触发度规计算 |
| `tab` | `?tab=ch` | 滚动并激活下方 Tab（`solver-app.js`） |

---

### 7.4 经典 Tab 求解器（`solver-app.js`）

#### Tab 与公开性

| Tab | ID | 公开 | 功能 |
|-----|-----|------|------|
| Blackhole | `panel-blackhole` | ✓ | 视界、光子球、ISCO、霍金系数、红移、ISCO 速度（km） |
| Orbit | `panel-orbit` | Token | 轨道速度、周期、逃逸速度；r > r_H |
| Gravity | `panel-gravity` | Token | g、势、梯度 |
| CH 系列 | `panel-ch` | 混合 | 分析器 + 层级表（公开）+ Custom（Token） |

#### Token 流程（严格）

1. 用户输入 → `GET /api/token_info?token=…` 必须 **200** 且 `remaining > 0`
2. 写入 `localStorage['sgt_api_token']`
3. 页面加载时重新校验；失败则清除，**不会**仅凭 localStorage 解锁
4. Kerr 背景 CH Analyze 亦需 Token

#### CH 分类着色

- `STRUCTURE-PRESERVED` → 绿色 `.ch-class-preserved`
- `STRUCTURE-DEFORMED` → 橙色 `.ch-class-deformed`

#### 经典 Blackhole Tab 与度规计算器的关系

两者均调用 `POST /api/blackhole`，但：

- **度规计算器**：面向研究者的一站式对比（M、a、滑块、曲线），默认首屏
- **Blackhole Tab**：原版 km 单位详细输出 + 质量预设按钮，保留兼容

修改 `/api/blackhole` 时需**同时**更新 `metric-calc.js` 与 `solver-app.js` 的解析/回退逻辑。

---

## 8. 思想实验（Canvas 定性演示）

**重要：** 均为橡皮筋/弹性网格**类比**，参数经教学缩放，**不是** SGT 场方程数值解。

| 文件 | 物理图像 | 交互要点 |
|------|----------|----------|
| `rubber-room.html` | 物质撑开介质；张力梯度 = 引力 | 拖拽蓝球、点击橙球、质量滑块 |
| `rubber-band-wave.html` | 介质跟不上源 → 应变波 | 静场/波模式、频率 1–10 |
| `rubber-band-shake.html` | 水平皮筋、慢振快波 | 频率与振幅教学缩放 |

**技术共性：**

- Canvas ~600×400，`requestAnimationFrame`，`devicePixelRatio` 适配
- 页内 `<style>`，引用 `../js/lang.js`
- 双语 CSS 必须用 `html.lang-zh .lang-en` 限定

---

## 9. SEO 与外部标识

| 类型 | 值 |
|------|------|
| 旗舰论文 DOI | `10.33774/coe-2026-jg7wz` |
| 扩展 DOI（meta） | `10.6084/m9.figshare.32399229` |
| ZKAV 论文 DOI（剑桥 Open Engage） | `10.33774/coe-2026-gl5pv` |
| IPSTP 协议 DOI（剑桥 Open Engage） | `10.33774/coe-2026-v2jzz` |
| ORCID | `0009-0004-8456-7107` |
| ZKAV 任务邮箱 | `zhijundi@qq.com` |
| 联盟 | `https://yuantai.ac.cn` |

`index.html` 含 JSON-LD（`ScholarlyArticle`）、Open Graph、Twitter Card、`hreflang`。  
`sitemap.xml` 列出主站各页及 `solver/` 与三个思想实验；**不含** `1/`。

---

## 10. 部署

### 10.1 上传范围

**必须上传：** 根目录 `*.html`（含 **`ai.html`**）、`css/`、`js/`、`assets/`、`solver/`、`robots.txt`、`sitemap.xml`

**勿上传：**

| 路径 | 原因 |
|------|------|
| `1/` | 历史备份；`robots.txt` 已 `Disallow: /1/` |
| `scripts/`、`partials/` | 本地维护可选 |
| `TECHNICAL.md`、`DEPLOY.md` | 文档可选 |

### 10.2 Nginx API 反代

```nginx
location /api/ {
    proxy_pass http://127.0.0.1:8716/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}

# SGT AI 精灵对话（路径与端口按实际后端调整）
location /chat {
    proxy_pass http://127.0.0.1:<CHAT_PORT>/chat;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_buffering off;          # 流式 SSE 建议关闭缓冲
    proxy_read_timeout 120s;
}
```

前端一律请求同源 `/api/...`，避免 CORS。

### 10.3 上线检查清单

- [ ] `assets/favicon.ico`、`assets/sgt-icon.png`、`assets/og-sgt.png` 可访问
- [ ] `GET /api/health` → `{"status":"ok"}`
- [ ] `POST /chat` 可返回回复（浮窗或 `/ai.html` 试一条）
- [ ] AI 回复 Markdown 列表/表格正常；「复制原文」可粘贴出完整 raw 文本
- [ ] `/solver/` 度规计算器可计算；页脚/API 状态正常
- [ ] 主站中英切换正常；思想实验三页动画正常
- [ ] 服务器根目录**无** `1/` 文件夹
- [ ] `framework.html` / `paper.html` 中 K、f_c 显示为 `--`（非明文）

### 10.4 缓存建议

静态资源可短缓存或 `?v=` 版本号；**API 响应不缓存**。更新 Solver 后核对 `API_VERSION` 与后端一致。

---

## 11. 内容维护规范

### 11.1 可检验预言措辞

避免赌咒式表述。推荐：

- 可被独立检验 / 可被未来观测验证或排除
- 构成对 SGT 的判定性检验

### 11.2 导航变更

- 主站 `site-nav` 保持学术主线
- 新工具通过 Hero、论文、ZKAV 导流，不塞进顶栏

### 11.3 修改 Solver API 时的同步清单

1. `solver/js/solver-app.js` — `API_VERSION`、端点、`normalize*`、`bhFallback`
2. `solver/js/metric-calc.js` — `FALLBACK`、`normalizeSuccess`、`ERR_MAP`、字段映射
3. 本文档 §7.2–7.3
4. 若健康检查字段变化 → `js/api-status.js`

---

## 12. 敏感参数与保密策略

### 12.1 脱敏对象

| 参数 | 符号 | 原数值 | 公开站策略 |
|------|------|--------|------------|
| 介质耦合常数 | K | （保密） | 页面显示 `--` |
| 临界撑开度 | f_c | （保密） | 页面显示 `--` |

### 12.2 已脱敏位置（生产根目录）

| 文件 | 处理方式 |
|------|----------|
| `framework.html` §1.4 参数表 | 值列 `--`；状态列「独立参数 · 目前仅对科研机构开放」 |
| `paper.html` 独立参数行 | `K = --, f_c = --（目前仅对科研机构开放）` |
| `js/effects.js` 首页 ticker | 已移除 K、f<sub>c</sub> 条目（仅保留导出观测量） |

`1/` 备份目录已同步脱敏，但仍**禁止部署**。

### 12.3 仍公开的相关信息

- 符号 K、f_c 及「两个独立参数」表述（无数值）
- 由 K、f_c 决定的**导出观测量**：`r_H = 1.6673 M`、ISCO、T_H 比等（反推风险需知悉）
- 预印本 PDF（站外）可能仍含数值 — 需单独核对

### 12.4 易混淆项（非 K）

- Solver CH 区默认 `eps = 0.05`：扰动阶参数 ε，**不是**介质耦合常数 K
- `0.866`：霍金温度系数，与 f_c 无关

### 12.5 全站审计方法

```bash
# 在仓库根目录搜索明文泄露（应无匹配）
rg "K\s*=\s*0\.05|f<sub>c</sub>\s*=\s*0\.8|>0\.05</td>.*K|>0\.8</td>.*f"
```

---

## 13. URL 参数速查

| 参数 | 作用范围 | 说明 |
|------|----------|------|
| `?lang=en` | 全站 | 覆盖语言 → localStorage |
| `?tab=blackhole\|orbit\|gravity\|ch` | Solver | 激活对应 Tab |
| `?M=10` | Solver | 预填质量（度规计算器 + 各 Tab） |
| `?a=0.3` | Solver | 预填自旋（度规计算器） |
| `?r=100` | Solver | 预填 Orbit/Gravity 半径 km |
| `?run=1` | Solver | 度规计算器自动计算；若 `tab=blackhole` 则 Tab 也计算 |

---

## 14. 浏览器与环境

| 项目 | 要求 |
|------|------|
| 浏览器 | Chromium / Firefox / Safari / Edge 最近两版 |
| JS | ES5+、Fetch、Canvas、localStorage |
| 构建 | 无；可选 `build-site.ps1` |
| 离线 | 除 API、Google Fonts、外部 DOI 外可本地打开 HTML |

---

## 15. 故障排查

| 现象 | 可能原因 | 处理 |
|------|----------|------|
| 切换英文整页白屏 | `.lang-en{display:none}` 命中 `<html>` | 改为 `html.lang-zh .lang-en` |
| 度规计算器一直回退常数 | API 未启或仍返回旧格式 | 查 Network `/api/blackhole`；对齐 §7.3.3 |
| Solver Tab 一直锁定 | Token 未通过 `token_info` 200 | 检查后端与额度 |
| API 页脚显示不可用 | 反代或 8716 未监听 | `GET /api/health` |
| Orbit 报错 | r ≤ r_H 或 Token 用尽 | 增大半径；重新申请 Token |
| CH Kerr + photon_sphere | 后端仅支持 ISCO | 改选 ISCO 结构 |
| 思想实验无动画 | JS 路径错误 | 控制台查 `lang.js` 404 |
| K/f_c 意外泄露 | 新页面未脱敏 | 跑 §12.5 搜索 |
| AI 回复挤成一段、无列表 | API 返回少换行；预处理未覆盖的新粘连模式 | 「复制原文」查 raw；扩展 `repairCompactMarkdown` |
| AI 表格仍异常 | pipe/Tab 格式新型变体 | 查 `sgt-tutor-md.js` 表修复函数；勿在 compact 修复前删 `\n` |
| 浮窗与工作台对话不同步 | localStorage 被禁或隐私模式 | 检查 `sgt_ai_genie_v1`；需允许站点存储 |
| `/chat` 超时或空回复 | 反代未配置或缓冲截断流 | 查 Network；Nginx `proxy_buffering off` |

---

## 16. 文件依赖关系

```
index.html ──┬── css/style.css
             ├── js/lang.js, main.js, effects.js
             ├── js/sgt-app.js ──► sgt-ai-store / sgt-tutor-md / sgt-ai-engine / sgt-tutor
             │                      └── marked + KaTeX (CDN)
             └── js/api-status.js（部分页）

ai.html ──┬── css/style.css, sgt-tutor.css, sgt-ai-page.css
          ├── marked + KaTeX (CDN)
          ├── sgt-tutor-md.js → sgt-ai-store.js → sgt-ai-engine.js → sgt-ai-page.js
          └── sgt-app.js (data-ai="false")

solver/index.html ──┬── ../js/lang.js
                    ├── ../js/sgt-app.js（可选 AI 浮窗）
                    ├── js/metric-calc.js  → POST /api/blackhole
                    └── js/solver-app.js   → /api/* + Token

rubber-*.html ── ../js/lang.js + ../js/sgt-app.js

partials/*.html ── build-site.ps1 ──► 主站 HTML（可选）
```

---

## 17. 版本记录

| 日期 | 说明 |
|------|------|
| 2026-06-02 | 初版：站点结构、双语、Solver API、思想实验、部署 |
| 2026-06-02 | robots/sitemap、partials、og-sgt、api-status、Solver 外链 JS |
| 2026-06-06 | **黑洞度规计算器**（`metric-calc.js`）为 Solver 默认首屏；`/api/blackhole` 双格式契约；K/f_c 全站脱敏；思想实验③ `rubber-band-shake.html`；文档全面重写 |
| 2026-06-06 | 首页 **SGT AI 精灵** 对话浮窗（`sgt-tutor.js` / `POST /chat`） |
| 2026-06-06 | **AI 子系统重构**：全站 `sgt-app.js` 注入；`ai.html` 工作台；`sgt-ai-engine/store/page` 拆分；localStorage 跨页持久化 + 临时归档 |
| 2026-06-06 | Markdown：`repairCompactMarkdown` 中/英粘连修复；pipe/Tab 表修复；助手回复 **复制原文** 按钮 |
| 2026-06-06 | 限额：6 轮 / 500 字；顶栏 EN 标签缩短；`css/sgt-ai-page.css` 浅色主题 |

---

*维护者：SGT 项目组 · 遇 API/前端不一致时，以浏览器 Network 实际响应为准，并回写本文 §7。*
