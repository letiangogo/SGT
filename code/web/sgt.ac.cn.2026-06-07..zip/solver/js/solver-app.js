(function () {
  'use strict';

  var API_BASE = '/api';
  var API_VERSION = '0.3.1';
  var TOKEN_KEY = 'sgt_api_token';
  var TIMEOUT_MS = 10000;
  var R_H_PER_M = 1.6673;
  var G = 6.67430e-11;
  var C = 299792458;
  var M_SUN = 1.98847e30;

  var SGT_BH = { r_h: R_H_PER_M, r_ph: 2.9954, isco: 4.23, t_coeff: 0.866 };
  var GR_BH = { r_h: 2, r_ph: 3, isco: 6, t_coeff: 1 };
  var C_KMS = 299792.458;

  var I18N = {
    zh: {
      colQty: '量', colDev: '偏差', noResult: '无结果',
      errMass: '请输入大于 0 的有效质量',
      errRadius: '请输入大于 0 的有效半径/距离',
      errBelowHorizon: '半径需大于视界半径（当前视界半径：{h} km）',
      errToken: '请先输入测试码',
      errApi: 'API 错误 ',
      errTimeout: '请求超时（10 秒）',
      errApiFallback: 'API 暂不可用，已显示 Ω-A1 客户端参考值',
      rHorizon: '视界 r_H', rPhoton: '光子球 r_ph', isco: 'ISCO',
      tCoeff: 'T_H 系数', redshift: '红移 z(r=10M)', iscoVel: 'ISCO 速度',
      orbVel: '轨道速度', orbPeriod: '轨道周期', escVel: '逃逸速度',
      gravAcc: '引力加速度', gravPot: '引力势', gravGrad: '引力梯度',
      tokenValid: '✅ 测试码有效 · 剩余次数：{r}/{m}',
      tokenExhausted: '❌ 次数已用尽，请重新申请',
      tokenInvalid: '❌ 无效的测试码',
      tokenChecking: '查询测试码状态…',
      errTokenExhausted: '测试码次数已用尽，请重新申请',
      chKerrToken: 'Kerr 背景需要测试码',
      chOrder0: 'ε⁰', chOrder1: 'ε¹', chOrder2: 'ε²',
      chPreserved: 'STRUCTURE-PRESERVED', chDeformed: 'STRUCTURE-DEFORMED',
      chHierarchyLoad: '加载层级数据…', chHierarchyFail: '层级数据加载失败',
      chRowExists: '存在性', chRowUnique: '唯一性', chRowOrder: '扰动阶数',
      chRowClass: '稳定性', chRowRef: '宪法参照',
      chHorizon: '视界', chPhoton: '光子球',
      chFeatEq: '特征方程', chCheck: '✓', chUnique: '唯一',
      chMargin: '安全裕度', chMarginVal: 'ε_SGT={es}, ε_c={ec}, 裕度 {m} 倍'
    },
    en: {
      colQty: 'Qty', colDev: 'Dev.', noResult: 'No results',
      errMass: 'Enter a valid mass greater than 0',
      errRadius: 'Enter a valid radius/distance greater than 0',
      errBelowHorizon: 'Radius must exceed the horizon (current horizon: {h} km)',
      errToken: 'Please enter a test token first',
      errApi: 'API error ',
      errTimeout: 'Request timed out (10 s)',
      errApiFallback: 'API unavailable — showing Ω-A1 client reference values',
      rHorizon: 'Horizon r_H', rPhoton: 'Photon sphere r_ph', isco: 'ISCO',
      tCoeff: 'T_H coeff.', redshift: 'Redshift z(r=10M)', iscoVel: 'ISCO velocity',
      orbVel: 'Orbital velocity', orbPeriod: 'Orbital period', escVel: 'Escape velocity',
      gravAcc: 'Gravitational acceleration', gravPot: 'Gravitational potential', gravGrad: 'Gravitational gradient',
      tokenValid: '✅ Token valid · Remaining: {r}/{m}',
      tokenExhausted: '❌ Quota exhausted — please reapply',
      tokenInvalid: '❌ Invalid token',
      tokenChecking: 'Checking token status…',
      errTokenExhausted: 'Token quota exhausted — please reapply',
      chKerrToken: 'Kerr background requires a test token',
      chOrder0: 'ε⁰', chOrder1: 'ε¹', chOrder2: 'ε²',
      chPreserved: 'STRUCTURE-PRESERVED', chDeformed: 'STRUCTURE-DEFORMED',
      chHierarchyLoad: 'Loading hierarchy…', chHierarchyFail: 'Failed to load hierarchy',
      chRowExists: 'Exists', chRowUnique: 'Uniqueness', chRowOrder: 'Perturbation order',
      chRowClass: 'Classification', chRowRef: 'Constitution ref.',
      chHorizon: 'Horizon', chPhoton: 'Photon sphere',
      chFeatEq: 'Characteristic eq.', chCheck: '✓', chUnique: 'unique',
      chMargin: 'Safety margin', chMarginVal: 'ε_SGT={es}, ε_c={ec}, margin {m}×'
    }
  };

  var tokenStatusCache = null;
  var tokenUnlocked = false;

  function lang() {
    return document.documentElement.classList.contains('lang-en') ? 'en' : 'zh';
  }

  function t(key, vars) {
    var s = I18N[lang()][key] || I18N.zh[key] || key;
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        s = s.replace('{' + k + '}', vars[k]);
      });
    }
    return s;
  }

  function parseNum(str) {
    if (str == null) return NaN;
    var v = parseFloat(String(str).trim().replace(/,/g, ''));
    return isNaN(v) ? NaN : v;
  }

  /** SGT event horizon in km: r_H = R_H_PER_M * (G*M*M_sun/c²) / 1000 */
  function sgtHorizonKm(massMsun) {
    var Mm = G * massMsun * M_SUN / (C * C);
    return R_H_PER_M * Mm / 1000;
  }

  function fmtHorizonKm(h) {
    if (h >= 1e6) return h.toPrecision(4);
    if (h >= 100) return h.toFixed(2);
    if (h >= 1) return h.toFixed(4);
    return h.toExponential(3);
  }

  function kmPerMsun(massMsun) {
    return sgtHorizonKm(massMsun) / R_H_PER_M;
  }

  function bhFallback(M) {
    var km = kmPerMsun(M);
    function zAt10M(rsFactor) {
      return 1 / Math.sqrt(1 - rsFactor / 10) - 1;
    }
    function iscoVel(iscoM) {
      return C_KMS * Math.sqrt(1 / (2 * iscoM));
    }
    return {
      sgt: {
        r_horizon: SGT_BH.r_h * M * km,
        r_photon: SGT_BH.r_ph * M * km,
        isco: SGT_BH.isco * M * km,
        hawking_coeff: SGT_BH.t_coeff,
        redshift_10m: zAt10M(2 * SGT_BH.r_h),
        isco_velocity: iscoVel(SGT_BH.isco)
      },
      gr: {
        r_horizon: GR_BH.r_h * M * km,
        r_photon: GR_BH.r_ph * M * km,
        isco: GR_BH.isco * M * km,
        hawking_coeff: GR_BH.t_coeff,
        redshift_10m: zAt10M(2),
        isco_velocity: iscoVel(GR_BH.isco)
      }
    };
  }

  function getToken() {
    return (localStorage.getItem(TOKEN_KEY) || '').trim();
  }

  function clearToken() {
    localStorage.removeItem(TOKEN_KEY);
    setTokenUnlocked(false);
  }

  function persistToken(val) {
    localStorage.setItem(TOKEN_KEY, val.trim());
  }

  function setTokenUnlocked(unlocked) {
    tokenUnlocked = !!unlocked;
    updateLockState();
    updateChLocks();
  }

  function statusText(kind, vars, lng) {
    var dict = I18N[lng] || I18N.zh;
    var s = dict[kind] || I18N.zh[kind] || kind;
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        s = s.replace('{' + k + '}', vars[k]);
      });
    }
    return s;
  }

  function applyTokenStatusDisplay(state) {
    tokenStatusCache = state;
    ['zh', 'en'].forEach(function (lng) {
      var el = document.getElementById('token-status-' + lng);
      if (!el) return;
      el.className = 'token-status lang-' + lng;
      if (!state || state.type === 'hidden') {
        el.classList.remove('visible');
        el.textContent = '';
        return;
      }
      el.classList.add('visible');
      if (state.type === 'loading') {
        el.classList.add('token-status-loading');
        el.textContent = statusText('tokenChecking', null, lng);
      } else if (state.type === 'invalid') {
        el.classList.add('token-status-error');
        el.textContent = statusText('tokenInvalid', null, lng);
      } else if (state.type === 'exhausted') {
        el.classList.add('token-status-error');
        el.textContent = statusText('tokenExhausted', null, lng);
      } else if (state.type === 'valid') {
        if (state.remaining <= 0) {
          el.classList.add('token-status-error');
          el.textContent = statusText('tokenExhausted', null, lng);
        } else if (state.max > 0 && state.remaining / state.max < 0.2) {
          el.classList.add('token-status-warn');
          el.textContent = statusText('tokenValid', { r: state.remaining, m: state.max }, lng);
        } else {
          el.classList.add('token-status-ok');
          el.textContent = statusText('tokenValid', { r: state.remaining, m: state.max }, lng);
        }
      }
    });
  }

  function parseTokenInfo(data) {
    var remaining = data.remaining != null ? data.remaining
      : data.remaining_uses != null ? data.remaining_uses
      : data.uses_remaining;
    var max = data.max != null ? data.max
      : data.max_uses != null ? data.max_uses
      : data.uses_max != null ? data.uses_max
      : data.total;
    return { remaining: Number(remaining), max: Number(max) };
  }

  function verifyToken(token) {
    token = (token || '').trim();
    if (!token) {
      applyTokenStatusDisplay({ type: 'hidden' });
      return Promise.resolve({ ok: false, reason: 'empty' });
    }
    applyTokenStatusDisplay({ type: 'loading' });
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
    return fetch(apiUrl('/token_info?token=' + encodeURIComponent(token)), {
      method: 'GET',
      signal: ctrl.signal
    }).then(function (res) {
      clearTimeout(timer);
      if (res.status === 404) {
        applyTokenStatusDisplay({ type: 'invalid' });
        return { ok: false, reason: '404' };
      }
      if (res.status !== 200) {
        applyTokenStatusDisplay({ type: 'invalid' });
        return { ok: false, reason: 'http_' + res.status };
      }
      return res.json().catch(function () { return {}; }).then(function (data) {
        var info = parseTokenInfo(data);
        if (isNaN(info.remaining) || isNaN(info.max)) {
          applyTokenStatusDisplay({ type: 'invalid' });
          return { ok: false, reason: 'bad_data' };
        }
        if (info.remaining <= 0) {
          applyTokenStatusDisplay({ type: 'exhausted', remaining: 0, max: info.max });
        } else {
          applyTokenStatusDisplay({ type: 'valid', remaining: info.remaining, max: info.max });
        }
        return { ok: true, info: info };
      });
    }).catch(function () {
      clearTimeout(timer);
      applyTokenStatusDisplay({ type: 'invalid' });
      return { ok: false, reason: 'network' };
    });
  }

  function refreshTokenInfo() {
    var tok = getToken();
    if (!tok) {
      setTokenUnlocked(false);
      return Promise.resolve();
    }
    return verifyToken(tok).then(function (result) {
      if (result.ok) {
        setTokenUnlocked(true);
      } else {
        clearToken();
        var input = document.getElementById('token-input');
        if (input) input.value = '';
      }
    });
  }

  function isTokenExhaustedError(err) {
    if (!err) return false;
    if (err.status === 403) return true;
    var msg = err.message || '';
    return msg.indexOf('用尽') !== -1 || msg.indexOf('exhausted') !== -1;
  }

  function updateLockState() {
    var unlocked = tokenUnlocked;
    [
      { name: 'orbit', fields: ['orb-mass', 'orb-radius'] },
      { name: 'gravity', fields: ['grav-mass', 'grav-dist'] }
    ].forEach(function (cfg) {
      var card = document.getElementById('card-' + cfg.name);
      var btn = document.getElementById('btn-' + cfg.name);
      if (unlocked) {
        card.classList.add('unlocked');
        card.classList.remove('locked');
        btn.disabled = false;
      } else {
        card.classList.remove('unlocked');
        card.classList.add('locked');
        btn.disabled = true;
      }
      cfg.fields.forEach(function (id) {
        var input = document.getElementById(id);
        if (input) input.disabled = !unlocked;
      });
      card.querySelectorAll('.preset-btn').forEach(function (pb) {
        pb.disabled = !unlocked;
      });
    });
  }

  function fmtNum(x, digits) {
    if (x == null || isNaN(x)) return '—';
    var ax = Math.abs(x);
    if (ax >= 1e12) return (x / 1e12).toPrecision(digits) + ' T';
    if (ax >= 1e9) return (x / 1e9).toPrecision(digits) + ' G';
    if (ax >= 1e6) return (x / 1e6).toPrecision(digits) + ' M';
    if (ax >= 1e3) return (x / 1e3).toPrecision(digits) + ' k';
    if (ax >= 1 || ax === 0) return Number(x).toPrecision(digits);
    return Number(x).toExponential(digits - 1);
  }

  function devClass(pct) {
    var a = Math.abs(pct);
    if (a >= 10) return 'dev-high';
    if (a >= 3) return 'dev-mid';
    return 'dev-low';
  }

  function devPct(sgt, gr) {
    if (gr == null || gr === 0 || isNaN(gr) || isNaN(sgt)) return null;
    return ((sgt - gr) / Math.abs(gr)) * 100;
  }

  function renderResults(container, rows) {
    if (!rows.length) {
      container.innerHTML = '<p class="results-empty">' + t('noResult') + '</p>';
      return;
    }
    var html = '<div class="results-header"><span>' + t('colQty') + '</span><span>SGT</span><span>GR</span><span>' + t('colDev') + '</span></div>';
    rows.forEach(function (r) {
      var pct = r.devPct != null ? r.devPct : devPct(r.sgt, r.gr);
      var pctStr = pct == null ? '—' : (pct >= 0 ? '+' : '') + Number(pct).toFixed(2) + '%';
      var cls = pct == null ? '' : devClass(pct);
      html += '<div class="result-row">' +
        '<span class="result-label">' + r.label + '</span>' +
        '<span class="result-sgt">' + r.sgtStr + '</span>' +
        '<span class="result-gr">' + r.grStr + '</span>' +
        '<span class="result-dev ' + cls + '">' + pctStr + '</span></div>';
    });
    container.innerHTML = html;
  }

  function makeRow(label, sgtVal, grVal, sgtStr, grStr, devPctVal) {
    if (sgtVal == null && sgtStr == null) return null;
    return {
      label: label,
      sgt: sgtVal,
      gr: grVal,
      sgtStr: sgtStr != null ? sgtStr : '—',
      grStr: grStr != null ? grStr : '—',
      devPct: devPctVal
    };
  }

  function pair(data) {
    return {
      sgt: data.SGT || data.sgt || {},
      gr: data.GR || data.gr || {},
      dev: data.deviation_percent || {}
    };
  }

  function showErr(container, msg) {
    container.innerHTML = '<p class="err-msg">' + msg + '</p>';
  }

  function apiUrl(path) {
    return API_BASE + (path.charAt(0) === '/' ? path : '/' + path);
  }

  function checkApiHealth() {
    var elZh = document.getElementById('api-status-zh');
    var elEn = document.getElementById('api-status-en');
    fetch(apiUrl('/health'))
      .then(function (res) { return res.ok ? res.json() : Promise.reject(); })
      .then(function (data) {
        if (data && data.status === 'ok') {
          var ver = data.version || API_VERSION;
          if (elZh) elZh.textContent = 'API v' + ver;
          if (elEn) elEn.textContent = 'API v' + ver;
        } else {
          throw new Error('bad status');
        }
      })
      .catch(function () {
        if (elZh) elZh.textContent = 'API 暂不可用';
        if (elEn) elEn.textContent = 'API unavailable';
      });
  }

  function getApiErrorMessage(data) {
    if (!data || typeof data !== 'object') return null;
    if (data.error) return String(data.error);
    if (data.detail) {
      return typeof data.detail === 'string' ? data.detail : String(data.detail);
    }
    return null;
  }

  function apiFetch(path, body, needToken) {
    var headers = { 'Content-Type': 'application/json' };
    if (needToken) {
      var tok = getToken();
      if (!tok) return Promise.reject(new Error(t('errToken')));
      headers['X-API-Token'] = tok;
    }
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
    return fetch(apiUrl(path), {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(body),
      signal: ctrl.signal
    }).then(function (res) {
      clearTimeout(timer);
      return res.json().catch(function () { return {}; }).then(function (data) {
        var errMsg = getApiErrorMessage(data);
        if (errMsg) {
          var err = new Error(errMsg);
          err.status = res.status;
          throw err;
        }
        if (!res.ok) {
          var httpErr = new Error(t('errApi') + res.status);
          httpErr.status = res.status;
          throw httpErr;
        }
        return data;
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') throw new Error(t('errTimeout'));
      throw err;
    });
  }

  function normalizeBlackhole(data, M) {
    if (!data.SGT && !data.sgt) {
      var fb = bhFallback(M);
      return [
        makeRow(t('rHorizon'), fb.sgt.r_horizon, fb.gr.r_horizon, fmtNum(fb.sgt.r_horizon, 4) + ' km', fmtNum(fb.gr.r_horizon, 4) + ' km', null),
        makeRow(t('rPhoton'), fb.sgt.r_photon, fb.gr.r_photon, fmtNum(fb.sgt.r_photon, 4) + ' km', fmtNum(fb.gr.r_photon, 4) + ' km', null),
        makeRow(t('isco'), fb.sgt.isco, fb.gr.isco, fmtNum(fb.sgt.isco, 4) + ' km', fmtNum(fb.gr.isco, 4) + ' km', null),
        makeRow(t('tCoeff'), fb.sgt.hawking_coeff, fb.gr.hawking_coeff, fmtNum(fb.sgt.hawking_coeff, 4), fmtNum(fb.gr.hawking_coeff, 4), null),
        makeRow(t('redshift'), fb.sgt.redshift_10m, fb.gr.redshift_10m, fmtNum(fb.sgt.redshift_10m, 4), fmtNum(fb.gr.redshift_10m, 4), null),
        makeRow(t('iscoVel'), fb.sgt.isco_velocity, fb.gr.isco_velocity, fmtNum(fb.sgt.isco_velocity, 4) + ' km/s', fmtNum(fb.gr.isco_velocity, 4) + ' km/s', null)
      ].filter(Boolean);
    }
    var p = pair(data);
    var s = p.sgt, g = p.gr, d = p.dev;
    return [
      makeRow(t('rHorizon'), s.r_H_m / 1000, g.r_H_m / 1000, fmtNum(s.r_H_m / 1000, 4) + ' km', fmtNum(g.r_H_m / 1000, 4) + ' km', d.r_H),
      makeRow(t('rPhoton'), s.r_ph_m / 1000, g.r_ph_m / 1000, fmtNum(s.r_ph_m / 1000, 4) + ' km', fmtNum(g.r_ph_m / 1000, 4) + ' km', d.r_ph),
      makeRow(t('isco'), s.r_ISCO_m / 1000, g.r_ISCO_m / 1000, fmtNum(s.r_ISCO_m / 1000, 4) + ' km', fmtNum(g.r_ISCO_m / 1000, 4) + ' km', d.r_ISCO),
      makeRow(t('tCoeff'), s.T_H_ratio, g.T_H_ratio, fmtNum(s.T_H_ratio, 4), fmtNum(g.T_H_ratio, 4), d.T_H),
      makeRow(t('redshift'), s.redshift_r10M, g.redshift_r10M, fmtNum(s.redshift_r10M, 4), fmtNum(g.redshift_r10M, 4), d.redshift),
      makeRow(t('iscoVel'), s.v_orb_ISCO_c, g.v_orb_ISCO_c, fmtNum(s.v_orb_ISCO_c, 4) + ' c', fmtNum(g.v_orb_ISCO_c, 4) + ' c', d.v_orb)
    ].filter(Boolean);
  }

  function normalizeOrbit(data) {
    var p = pair(data);
    var s = p.sgt, g = p.gr, d = p.dev;
    return [
      makeRow(t('orbVel'), s.v_orb_m_per_s, g.v_orb_m_per_s, fmtNum(s.v_orb_m_per_s, 4) + ' m/s', fmtNum(g.v_orb_m_per_s, 4) + ' m/s', d.v_orb),
      makeRow(t('orbPeriod'), s.T_orb_s, g.T_orb_s, fmtNum(s.T_orb_s, 4) + ' s', fmtNum(g.T_orb_s, 4) + ' s', d.T_orb),
      makeRow(t('escVel'), s.v_esc_m_per_s, g.v_esc_m_per_s, fmtNum(s.v_esc_m_per_s, 4) + ' m/s', fmtNum(g.v_esc_m_per_s, 4) + ' m/s', d.v_esc)
    ].filter(Boolean);
  }

  function normalizeGravity(data) {
    var p = pair(data);
    var s = p.sgt, g = p.gr, d = p.dev;
    return [
      makeRow(t('gravAcc'), s.g_m_per_s2, g.g_m_per_s2, fmtNum(s.g_m_per_s2, 4) + ' m/s²', fmtNum(g.g_m_per_s2, 4) + ' m/s²', d.g),
      makeRow(t('gravPot'), s.V_J_per_kg, g.V_J_per_kg, fmtNum(s.V_J_per_kg, 4) + ' J/kg', fmtNum(g.V_J_per_kg, 4) + ' J/kg', d.V),
      makeRow(t('gravGrad'), s.grad_m_per_s2_per_m, g.grad_m_per_s2_per_m, fmtNum(s.grad_m_per_s2_per_m, 4) + ' m/s²/m', fmtNum(g.grad_m_per_s2_per_m, 4) + ' m/s²/m', d.grad)
    ].filter(Boolean);
  }

  function setLoading(btn, on) {
    btn.classList.toggle('loading', on);
    if (on) {
      btn.disabled = true;
    } else if (btn.id === 'btn-blackhole' || btn.id === 'btn-ch-analyze') {
      updateChAnalyzeState();
      btn.disabled = false;
    } else if (btn.id === 'btn-ch-custom') {
      updateChLocks();
    } else {
      updateLockState();
    }
  }

  function validateMass(M, out) {
    if (!M || M <= 0 || !isFinite(M)) {
      showErr(out, t('errMass'));
      return false;
    }
    return true;
  }

  function validateOutsideHorizon(M, r, out) {
    var h = sgtHorizonKm(M);
    if (!r || r <= 0 || !isFinite(r)) {
      showErr(out, t('errRadius'));
      return false;
    }
    if (r <= h) {
      showErr(out, t('errBelowHorizon', { h: fmtHorizonKm(h) }));
      return false;
    }
    return true;
  }

  function epsOrderLabel(n) {
    if (n === 0) return t('chOrder0');
    if (n === 1) return t('chOrder1');
    if (n === 2) return t('chOrder2');
    return 'ε^' + n;
  }

  function classLabel(cls) {
    if (!cls) return '—';
    if (cls.indexOf('PRESERVED') !== -1) {
      return '<span class="ch-class-preserved">' + t('chPreserved') + '</span>';
    }
    if (cls.indexOf('DEFORMED') !== -1) {
      return '<span class="ch-class-deformed">' + t('chDeformed') + '</span>';
    }
    return cls;
  }

  function devPctStr(pct) {
    if (pct == null || isNaN(pct)) return '—';
    return '<span class="' + devClass(pct) + '">' + (pct >= 0 ? '+' : '') + Number(pct).toFixed(2) + '%</span>';
  }

  function apiGet(path) {
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
    return fetch(apiUrl(path), { method: 'GET', signal: ctrl.signal })
      .then(function (res) {
        clearTimeout(timer);
        return res.json().catch(function () { return {}; }).then(function (data) {
          var errMsg = getApiErrorMessage(data);
          if (errMsg) {
            var err = new Error(errMsg);
            err.status = res.status;
            throw err;
          }
          if (!res.ok) {
            var httpErr = new Error(t('errApi') + res.status);
            httpErr.status = res.status;
            throw httpErr;
          }
          return data;
        });
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (err.name === 'AbortError') throw new Error(t('errTimeout'));
        throw err;
      });
  }

  function updateChLocks() {
    var unlocked = tokenUnlocked;
    var card = document.getElementById('card-ch-custom');
    var btn = document.getElementById('btn-ch-custom');
    ['ch-alpha', 'ch-beta'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.disabled = !unlocked;
    });
    if (unlocked) {
      card.classList.add('unlocked');
      card.classList.remove('locked');
      btn.disabled = false;
    } else {
      card.classList.remove('unlocked');
      card.classList.add('locked');
      btn.disabled = true;
    }
    updateChAnalyzeState();
  }

  function updateChAnalyzeState() {
    var bg = document.getElementById('ch-background').value;
    var needTok = bg === 'kerr' && !tokenUnlocked;
    document.getElementById('btn-ch-analyze').disabled = needTok;
    document.querySelectorAll('.ch-kerr-hint').forEach(function (el) {
      el.hidden = !needTok;
    });
  }

  function renderChAnalyzeSchwarzschild(data, bg, structure) {
    var html = '<div class="ch-result-block"><p><strong>' + bg + ' · ' + structure + '</strong></p>';
    if (structure === 'isco' || data.r_isco_M != null) {
      var devR = data.r_isco_gr_M ? ((data.r_isco_M - data.r_isco_gr_M) / data.r_isco_gr_M * 100) : null;
      html += '<p>ISCO: <span class="val-sgt">' + fmtNum(data.r_isco_M, 4) + ' M</span> · GR <span class="val-gr">' + fmtNum(data.r_isco_gr_M, 4) + ' M</span> · ' + devPctStr(devR) + '</p>';
      html += '<p>Δr: <span class="val-sgt">' + fmtNum(data.delta_r_M, 4) + ' M</span></p>';
      html += '<p>' + t('chRowOrder') + ': ' + epsOrderLabel(data.perturbation_order) + ' · ' + t('chRowClass') + ': ' + classLabel(data.classification) + '</p>';
      html += '<p>ε¹: <span class="val-sgt">' + fmtNum(data.first_order_coefficient, 4) + '</span> · ε²: <span class="val-sgt">' + (data.second_order_coefficient != null ? fmtNum(data.second_order_coefficient, 4) : '—') + '</span></p>';
      if (data.circular_orbit_params) {
        var c = data.circular_orbit_params;
        html += '<p><strong><span class="lang-zh">圆轨道</span><span class="lang-en">Circular orbit</span></strong></p>';
        html += '<p>L: SGT <span class="val-sgt">' + fmtNum(c.L_M, 4) + '</span> · GR <span class="val-gr">' + fmtNum(c.L_gr_M, 4) + '</span> · ' + devPctStr(c.L_deviation_percent) + '</p>';
        html += '<p>Ω: SGT <span class="val-sgt">' + fmtNum(c.Omega_M, 4) + '</span> · GR <span class="val-gr">' + fmtNum(c.Omega_gr_M, 4) + '</span> · ' + devPctStr(c.Omega_deviation_percent) + '</p>';
      }
    } else {
      var devPh = data.r_ph_gr_M ? ((data.r_ph_M - data.r_ph_gr_M) / data.r_ph_gr_M * 100) : null;
      html += '<p>r_ph: <span class="val-sgt">' + fmtNum(data.r_ph_M, 4) + ' M</span> · GR <span class="val-gr">' + fmtNum(data.r_ph_gr_M, 4) + ' M</span> · ' + devPctStr(devPh) + '</p>';
      html += '<p>Δr: <span class="val-sgt">' + fmtNum(data.delta_r_M, 4) + ' M</span></p>';
      html += '<p>' + t('chRowOrder') + ': ' + epsOrderLabel(data.perturbation_order) + ' · ' + t('chRowClass') + ': ' + classLabel(data.classification) + '</p>';
      html += '<p>ε¹: <span class="val-sgt">' + fmtNum(data.first_order_coefficient, 4) + '</span>';
      if (data.eps_sgt_estimate != null) html += ' · ε_SGT≈' + fmtNum(data.eps_sgt_estimate, 4);
      html += '</p>';
    }
    return html + '</div>';
  }

  function renderChAnalyzeKerr(data) {
    var html = '<div class="ch-result-block"><p><strong>Kerr · ISCO</strong></p>';
    html += '<p>' + t('chRowClass') + ': ' + classLabel(data.classification) + '</p>';
    if (data.first_order_coefficient_prograde != null) {
      html += '<p>ε¹ pro: <span class="val-sgt">' + fmtNum(data.first_order_coefficient_prograde, 4) + '</span> · retro: <span class="val-sgt">' + fmtNum(data.first_order_coefficient_retrograde, 4) + '</span></p>';
    }
    if (data.comparison_with_sgt) {
      var c = data.comparison_with_sgt;
      html += '<p>SGT/Kerr: <span class="val-sgt">' + fmtNum(c.sgt_kerr_ratio_percent, 4) + '%</span> (SGT ' + fmtNum(c.sgt_isco_linear_coefficient, 4) + ' · Kerr ' + fmtNum(c.kerr_linear_coefficient, 4) + ')</p>';
    }
    if (data.prograde_data && data.prograde_data.length) {
      html += '<table class="ch-kerr-table"><thead><tr><th>a</th><th>exact</th><th>linear</th><th>err%</th></tr></thead><tbody>';
      data.prograde_data.slice(0, 8).forEach(function (row) {
        html += '<tr><td>' + fmtNum(row.a, 3) + '</td><td class="val-sgt">' + fmtNum(row.exact, 4) + '</td><td class="val-gr">' + fmtNum(row.linear, 4) + '</td><td>' + devPctStr(row.error_percent) + '</td></tr>';
      });
      if (data.prograde_data.length > 8) html += '<tr><td colspan="4">…</td></tr>';
      html += '</tbody></table>';
    }
    return html + '</div>';
  }

  function renderChHierarchy(data) {
    var cols = [
      { key: 'horizon', label: t('chHorizon') },
      { key: 'isco', label: 'ISCO' },
      { key: 'photon_sphere', label: t('chPhoton') }
    ];
    var rows = [
      { label: t('chFeatEq'), fn: function (c) { return c.sgt_constitution_reference || '—'; } },
      { label: t('chRowExists'), fn: function (c) { return c.exists ? t('chCheck') : '—'; } },
      { label: t('chRowUnique'), fn: function (c) { return c.uniqueness || '—'; } },
      { label: t('chRowOrder'), fn: function (c) { return epsOrderLabel(c.perturbation_order); } },
      { label: t('chRowClass'), fn: function (c) { return classLabel(c.classification); } }
    ];
    var html = '<div class="ch-hierarchy-wrap"><table class="ch-hierarchy-table"><thead><tr><th></th>';
    cols.forEach(function (col) { html += '<th>' + col.label + '</th>'; });
    html += '</tr></thead><tbody>';
    rows.forEach(function (row) {
      html += '<tr><td class="col-label">' + row.label + '</td>';
      cols.forEach(function (col) {
        html += '<td>' + row.fn(data[col.key] || {}) + '</td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table></div><div class="ch-summary">';
    if (data.rigidity_hierarchy_metric) {
      html += '<p><span class="lang-zh">度规微扰下：</span><span class="lang-en">Metric perturbation: </span><strong>' + data.rigidity_hierarchy_metric + '</strong></p>';
    }
    if (data.rigidity_hierarchy_spin) {
      html += '<p><span class="lang-zh">自旋微扰下：</span><span class="lang-en">Spin: </span>' + data.rigidity_hierarchy_spin + '</p>';
    }
    if (data.safety_margin) {
      var sm = data.safety_margin;
      html += '<p>' + t('chMargin') + ': ' + t('chMarginVal', {
        es: fmtNum(sm.eps_sgt, 3), ec: fmtNum(sm.eps_critical, 3), m: fmtNum(sm.margin, 4)
      }) + '</p>';
    }
    return html + '</div>';
  }

  function renderChCustom(data) {
    var html = '<div class="ch-result-block">';
    html += '<p>ε_eff = <span class="val-sgt">' + fmtNum(data.effective_epsilon, 4) + '</span> (α−β)</p>';
    html += '<p>ISCO: <span class="val-sgt">' + fmtNum(data.r_isco_M, 4) + ' M</span> · Δr <span class="val-sgt">' + fmtNum(data.delta_r_M, 4) + ' M</span></p>';
    if (data.note) html += '<p><em>' + data.note + '</em></p>';
    html += '<p class="lang-zh"><em>一阶微扰仅依赖 (α−β)；若 α=β 则一阶修正消失。</em></p>';
    html += '<p class="lang-en"><em>First-order perturbation depends only on (α−β); if α=β the first-order term vanishes.</em></p></div>';
    return html;
  }

  function loadChHierarchy() {
    var out = document.getElementById('results-ch-hierarchy');
    out.innerHTML = '<p class="results-empty">' + t('chHierarchyLoad') + '</p>';
    apiGet('/ch/hierarchy')
      .then(function (data) { out.innerHTML = renderChHierarchy(data); })
      .catch(function () { out.innerHTML = '<p class="err-msg">' + t('chHierarchyFail') + '</p>'; });
  }

  function initSolverTabs() {
    document.querySelectorAll('.solver-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        var id = tab.getAttribute('data-tab');
        document.querySelectorAll('.solver-tab').forEach(function (t) {
          t.classList.toggle('active', t === tab);
          t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
        });
        document.querySelectorAll('.solver-panel').forEach(function (p) {
          p.classList.toggle('active', p.id === 'panel-' + id);
        });
      });
    });
  }

  function requireToken(out) {
    if (!tokenUnlocked || !getToken()) {
      showErr(out, t('errToken'));
      return false;
    }
    return true;
  }

  document.querySelectorAll('.preset-row').forEach(function (row) {
    var targetId = row.getAttribute('data-preset-for');
    row.querySelectorAll('.preset-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        document.getElementById(targetId).value = btn.getAttribute('data-value');
      });
    });
  });

  document.getElementById('btn-blackhole').addEventListener('click', function () {
    var btn = this;
    var out = document.getElementById('results-blackhole');
    var M = parseNum(document.getElementById('bh-mass').value);
    if (!validateMass(M, out)) return;
    setLoading(btn, true);
    apiFetch('/blackhole', { M: M }, false)
      .then(function (data) {
        renderResults(out, normalizeBlackhole(data, M));
      })
      .catch(function (err) {
        if (err.message && err.message !== t('errTimeout') && err.message.indexOf(t('errApi')) !== 0) {
          showErr(out, err.message);
          return;
        }
        renderResults(out, normalizeBlackhole({}, M));
        out.insertAdjacentHTML('beforeend', '<p class="err-msg" style="margin-top:10px;font-size:0.72rem;">' + t('errApiFallback') + '</p>');
      })
      .finally(function () { setLoading(btn, false); });
  });

  document.getElementById('btn-orbit').addEventListener('click', function () {
    var btn = this;
    var out = document.getElementById('results-orbit');
    var M = parseNum(document.getElementById('orb-mass').value);
    var r = parseNum(document.getElementById('orb-radius').value);
    if (!requireToken(out)) return;
    if (!validateMass(M, out)) return;
    if (!validateOutsideHorizon(M, r, out)) return;
    setLoading(btn, true);
    apiFetch('/orbit', { M: M, r: r }, true)
      .then(function (data) {
        renderResults(out, normalizeOrbit(data));
      })
      .catch(function (err) {
        if (isTokenExhaustedError(err)) {
          showErr(out, t('errTokenExhausted'));
          refreshTokenInfo();
          return;
        }
        showErr(out, err.message);
      })
      .finally(function () { setLoading(btn, false); });
  });

  document.getElementById('btn-gravity').addEventListener('click', function () {
    var btn = this;
    var out = document.getElementById('results-gravity');
    var M = parseNum(document.getElementById('grav-mass').value);
    var d = parseNum(document.getElementById('grav-dist').value);
    if (!requireToken(out)) return;
    if (!validateMass(M, out)) return;
    if (!validateOutsideHorizon(M, d, out)) return;
    setLoading(btn, true);
    apiFetch('/gravity', { M: M, r: d }, true)
      .then(function (data) {
        renderResults(out, normalizeGravity(data));
      })
      .catch(function (err) {
        if (isTokenExhaustedError(err)) {
          showErr(out, t('errTokenExhausted'));
          refreshTokenInfo();
          return;
        }
        showErr(out, err.message);
      })
      .finally(function () { setLoading(btn, false); });
  });

  document.getElementById('btn-save-token').addEventListener('click', function () {
    var input = document.getElementById('token-input');
    var val = input.value.trim();
    if (!val) {
      clearToken();
      input.value = '';
      applyTokenStatusDisplay({ type: 'hidden' });
      return;
    }
    verifyToken(val).then(function (result) {
      if (result.ok) {
        persistToken(val);
        setTokenUnlocked(true);
      } else {
        clearToken();
        input.value = '';
        setTokenUnlocked(false);
      }
    });
  });

  document.getElementById('ch-background').addEventListener('change', updateChAnalyzeState);

  document.getElementById('btn-ch-analyze').addEventListener('click', function () {
    var btn = this;
    var out = document.getElementById('results-ch-analyze');
    var bg = document.getElementById('ch-background').value;
    var structure = document.getElementById('ch-structure').value;
    var eps = parseNum(document.getElementById('ch-eps').value);
    if (isNaN(eps) || eps < 0 || eps > 1) {
      showErr(out, lang() === 'zh' ? 'ε 须在 0–1 之间' : 'ε must be between 0 and 1');
      return;
    }
    if (bg === 'kerr' && !requireToken(out)) return;
    setLoading(btn, true);
    apiFetch('/ch/analyze', { background: bg, structure: structure, eps: eps, a_star: 0.0 }, bg === 'kerr')
      .then(function (data) {
        if (bg === 'kerr') {
          out.innerHTML = renderChAnalyzeKerr(data);
        } else {
          out.innerHTML = renderChAnalyzeSchwarzschild(data, bg, structure);
        }
      })
      .catch(function (err) {
        if (isTokenExhaustedError(err)) {
          showErr(out, t('errTokenExhausted'));
          refreshTokenInfo();
          return;
        }
        showErr(out, err.message);
      })
      .finally(function () { setLoading(btn, false); });
  });

  document.getElementById('btn-ch-custom').addEventListener('click', function () {
    var btn = this;
    var out = document.getElementById('results-ch-custom');
    if (!requireToken(out)) return;
    var alpha = parseNum(document.getElementById('ch-alpha').value);
    var beta = parseNum(document.getElementById('ch-beta').value);
    if (isNaN(alpha) || isNaN(beta) || alpha < 0 || alpha > 1 || beta < 0 || beta > 1) {
      showErr(out, lang() === 'zh' ? 'α、β 须在 0–1 之间' : 'α and β must be between 0 and 1');
      return;
    }
    setLoading(btn, true);
    apiFetch('/ch/custom', { alpha: alpha, beta: beta }, true)
      .then(function (data) { out.innerHTML = renderChCustom(data); })
      .catch(function (err) {
        if (isTokenExhaustedError(err)) {
          showErr(out, t('errTokenExhausted'));
          refreshTokenInfo();
          return;
        }
        showErr(out, err.message);
      })
      .finally(function () { setLoading(btn, false); });
  });

  function openPrecision(e) {
    if (e) e.preventDefault();
    document.getElementById('modal-precision').classList.add('open');
  }
  document.getElementById('link-precision').addEventListener('click', openPrecision);
  document.getElementById('link-precision-en').addEventListener('click', openPrecision);
  var linkPrecisionMc = document.getElementById('link-precision-mc');
  if (linkPrecisionMc) linkPrecisionMc.addEventListener('click', openPrecision);
  document.getElementById('modal-close').addEventListener('click', function () {
    document.getElementById('modal-precision').classList.remove('open');
  });
  document.getElementById('modal-precision').addEventListener('click', function (e) {
    if (e.target === this) this.classList.remove('open');
  });

  setTokenUnlocked(false);
  initSolverTabs();
  loadChHierarchy();
  updateChAnalyzeState();
  var saved = getToken();
  if (saved) {
    document.getElementById('token-input').value = saved;
    verifyToken(saved).then(function (result) {
      if (result.ok) {
        setTokenUnlocked(true);
      } else {
        clearToken();
        document.getElementById('token-input').value = '';
      }
    });
  }

  function applyUrlParams() {
    try {
      var params = new URLSearchParams(window.location.search);
      var tab = params.get('tab');
      var M = params.get('M');
      if (tab) {
        var tabBtn = document.querySelector('.solver-tab[data-tab="' + tab + '"]');
        if (tabBtn) tabBtn.click();
      }
      if (M) {
        var m = parseFloat(M);
        if (!isNaN(m) && m > 0) {
          ['bh-mass', 'orb-mass', 'grav-mass', 'mc-mass'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.value = String(m);
          });
        }
      }
      var aParam = params.get('a');
      if (aParam != null) {
        var av = parseFloat(aParam);
        if (!isNaN(av)) {
          var mcSpin = document.getElementById('mc-spin');
          if (mcSpin) mcSpin.value = String(av);
        }
      }
      var r = params.get('r');
      if (r) {
        var rv = parseFloat(r);
        if (!isNaN(rv) && rv > 0) {
          var or = document.getElementById('orb-radius');
          var gd = document.getElementById('grav-dist');
          if (or) or.value = String(rv);
          if (gd) gd.value = String(rv);
        }
      }
      if (params.get('run') === '1' && tab === 'blackhole') {
        var btnBh = document.getElementById('btn-blackhole');
        if (btnBh) btnBh.click();
      }
    } catch (e) {}
  }

  applyUrlParams();
  checkApiHealth();
})();