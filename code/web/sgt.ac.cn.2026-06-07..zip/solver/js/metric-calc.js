/**
 * SGT Solver — Blackhole Metric Calculator (default landing tool)
 */
(function () {
  'use strict';

  var API = '/api/blackhole';
  var TIMEOUT_MS = 10000;
  var GOLD = '#D4A017';
  var FALLBACK = {
    r_H: 1.6673,
    r_ph: 2.9954,
    r_ISCO_SGT: 4.23,
    r_ISCO_GR: 6.0,
    T_H_ratio: 0.866
  };

  var state = { data: null, r: 6 };

  var I18N = {
    zh: {
      title: '黑洞度规计算器',
      subtitle: 'Blackhole Metric Calculator',
      mass: '质量 M',
      spin: '自旋 a',
      spinHint: '范围 0 – 0.9',
      compute: '计算',
      computing: '计算中…',
      errM: '质量必须为正数',
      errA: '自旋参数必须在 0 到 0.9 之间',
      errMissingM: '请输入质量',
      errSolver: '求解器未收敛，请调整参数后重试',
      errInternal: '服务器内部错误，请稍后重试',
      errNetwork: '网络连接失败，请检查网络后重试',
      errGeneric: '请求失败，请稍后重试',
      colQty: '物理量',
      colSgt: 'SGT',
      colGr: 'GR',
      colDev: '差异',
      rowIsco: 'ISCO / M',
      rowPh: '光子球 r<sub>ph</sub> / M',
      rowH: '视界 r<sub>H</sub> / M',
      rowTh: 'T<sub>H</sub> 比',
      rowG: '引力加速度 g (r={r}M)',
      rowV: '轨道速度 v (r={r}M)',
      sliderLabel: '对比半径 r',
      currentR: '当前 r = {r} M',
      compareAtR: '在此半径对比',
      detailG: '引力加速度 (r={r}M)',
      detailV: '轨道速度 (r={r}M)',
      empty: '输入 M、a 后点击计算',
      fallbackNote: 'API 简版响应，径向曲线为客户端估算',
      chartTitle: 'g(r) 对比曲线',
      chartG: '引力加速度 g',
      chartV: '轨道速度 v'
    },
    en: {
      title: 'Blackhole Metric Calculator',
      subtitle: 'SGT vs GR metric comparison',
      mass: 'Mass M',
      spin: 'Spin a',
      spinHint: 'Range 0 – 0.9',
      compute: 'Compute',
      computing: 'Computing…',
      errM: 'M must be positive',
      errA: 'a must be in [0, 0.9]',
      errMissingM: 'M is required',
      errSolver: 'Solver did not converge — adjust parameters and retry',
      errInternal: 'Internal server error — please try again later',
      errNetwork: 'Network error — check your connection and retry',
      errGeneric: 'Request failed — please try again later',
      colQty: 'Quantity',
      colSgt: 'SGT',
      colGr: 'GR',
      colDev: 'Dev.',
      rowIsco: 'ISCO / M',
      rowPh: 'Photon sphere r<sub>ph</sub> / M',
      rowH: 'Horizon r<sub>H</sub> / M',
      rowTh: 'T<sub>H</sub> ratio',
      rowG: 'Gravity g (r={r}M)',
      rowV: 'Orbital velocity v (r={r}M)',
      sliderLabel: 'Radius r',
      currentR: 'Current r = {r} M',
      compareAtR: 'Compare at this radius',
      detailG: 'Gravitational acceleration (r={r}M)',
      detailV: 'Orbital velocity (r={r}M)',
      empty: 'Enter M and a, then click Compute',
      fallbackNote: 'Simplified API — radial curves use client estimates',
      chartTitle: 'g(r) comparison',
      chartG: 'Acceleration g',
      chartV: 'Orbital velocity v'
    }
  };

  var ERR_MAP = {
    zh: {
      INVALID_M: '质量必须为正数',
      INVALID_A: '自旋参数必须在 0 到 0.9 之间',
      MISSING_M: '请输入质量',
      SOLVER_FAILED: '求解器未收敛，请调整参数后重试',
      INTERNAL: '服务器内部错误，请稍后重试'
    },
    en: {
      INVALID_M: 'M must be positive',
      INVALID_A: 'a must be in [0, 0.9]',
      MISSING_M: 'M is required',
      SOLVER_FAILED: 'Solver did not converge — adjust parameters and retry',
      INTERNAL: 'Internal server error — please try again later'
    }
  };

  function lng() {
    return document.documentElement.classList.contains('lang-en') ? 'en' : 'zh';
  }

  function t(key, vars) {
    var s = (I18N[lng()] || I18N.zh)[key] || key;
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        s = s.replace('{' + k + '}', vars[k]);
      });
    }
    return s;
  }

  function $(id) { return document.getElementById(id); }

  function parseNum(str) {
    if (str == null) return NaN;
    var v = parseFloat(String(str).trim().replace(/,/g, ''));
    return isNaN(v) ? NaN : v;
  }

  function fmt(x, d) {
    if (x == null || isNaN(x)) return '—';
    return Number(x).toFixed(d == null ? 3 : d);
  }

  function devPct(sgt, gr) {
    if (gr == null || gr === 0 || isNaN(gr) || isNaN(sgt)) return null;
    return ((sgt - gr) / Math.abs(gr)) * 100;
  }

  function devStr(pct) {
    if (pct == null || isNaN(pct)) return '—';
    return (pct >= 0 ? '+' : '') + pct.toFixed(1) + '%';
  }

  function isHighlight(pct) {
    return pct != null && Math.abs(pct) > 10;
  }

  function showFieldErr(el, msg) {
    if (!el) return;
    el.textContent = msg || '';
    el.style.display = msg ? 'block' : 'none';
  }

  function validateInputs() {
    var M = parseNum($('mc-mass').value);
    var a = parseNum($('mc-spin').value);
    var ok = true;
    if (!M || M <= 0 || !isFinite(M)) {
      showFieldErr($('mc-err-m'), t('errM'));
      ok = false;
    } else {
      showFieldErr($('mc-err-m'), '');
    }
    if (isNaN(a) || a < 0 || a > 0.9) {
      showFieldErr($('mc-err-a'), t('errA'));
      ok = false;
    } else {
      showFieldErr($('mc-err-a'), '');
    }
    return ok ? { M: M, a: isNaN(a) ? 0 : a } : null;
  }

  function errMessage(code, fallback) {
    var map = ERR_MAP[lng()] || ERR_MAP.zh;
    return map[code] || fallback || t('errGeneric');
  }

  function fromLegacy(data, M, a) {
    if (!(data.SGT || data.sgt)) return null;
    var s = data.SGT || data.sgt;
    var g = data.GR || data.gr || {};
    var base = fallbackData(M, a);
    if (s.T_H_ratio != null) base.T_H_ratio = s.T_H_ratio;
    if (g.T_H_ratio != null && s.T_H_ratio == null) base.T_H_ratio = s.T_H_ratio;
    base._legacy = true;
    return base;
  }

  function fallbackData(M, a) {
    return {
      status: 'success',
      M: M,
      a: a || 0,
      r_H: FALLBACK.r_H,
      r_ph: FALLBACK.r_ph,
      r_ISCO_SGT: FALLBACK.r_ISCO_SGT,
      r_ISCO_GR: FALLBACK.r_ISCO_GR,
      T_H_ratio: FALLBACK.T_H_ratio,
      r_grid: null,
      _fallback: true
    };
  }

  function normalizeSuccess(data, M, a) {
    if (data.status === 'success' || data.r_ISCO_SGT != null) {
      return {
        status: 'success',
        M: data.M != null ? data.M : M,
        a: data.a != null ? data.a : a,
        r_H: data.r_H != null ? data.r_H : FALLBACK.r_H,
        r_ph: data.r_ph != null ? data.r_ph : FALLBACK.r_ph,
        r_ISCO_SGT: data.r_ISCO_SGT != null ? data.r_ISCO_SGT : FALLBACK.r_ISCO_SGT,
        r_ISCO_GR: data.r_ISCO_GR != null ? data.r_ISCO_GR : FALLBACK.r_ISCO_GR,
        T_H_ratio: data.T_H_ratio != null ? data.T_H_ratio : FALLBACK.T_H_ratio,
        r_grid: data.r_grid || null,
        g_SGT: data.g_SGT || null,
        g_GR: data.g_GR || null,
        v_SGT: data.v_SGT || null,
        v_GR: data.v_GR || null
      };
    }
    var leg = fromLegacy(data, M, a);
    if (leg) return leg;
    return fallbackData(M, a);
  }

  function fetchMetric(M, a) {
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
    return fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ M: M, a: a }),
      signal: ctrl.signal
    }).then(function (res) {
      clearTimeout(timer);
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (data.status === 'error') {
          var err = new Error(errMessage(data.error_code, data.message));
          err.code = data.error_code;
          throw err;
        }
        if (data.error || data.detail) {
          var msg = data.error || data.detail;
          var e2 = new Error(typeof msg === 'string' ? msg : t('errGeneric'));
          e2.httpStatus = res.status;
          throw e2;
        }
        if (!res.ok) {
          throw new Error(t('errGeneric'));
        }
        return normalizeSuccess(data, M, a);
      });
    }).catch(function (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') throw new Error(t('errNetwork'));
      if (err.message && err.code) throw err;
      if (err.message && err.message.indexOf('Failed to fetch') !== -1) throw new Error(t('errNetwork'));
      throw err;
    });
  }

  function interp(r, grid, values) {
    if (!grid || !values || !grid.length) return null;
    if (r <= grid[0]) return values[0];
    if (r >= grid[grid.length - 1]) return values[values.length - 1];
    for (var i = 0; i < grid.length - 1; i++) {
      if (r >= grid[i] && r <= grid[i + 1]) {
        var t0 = (r - grid[i]) / (grid[i + 1] - grid[i]);
        return values[i] + t0 * (values[i + 1] - values[i]);
      }
    }
    return null;
  }

  function clientG(r, isSgt, data) {
    var gGr = 1 / (r * r);
    if (!isSgt) return gGr;
    var h = data.r_H || FALLBACK.r_H;
    return gGr * Math.pow(2 / h, 2);
  }

  function clientV(r, isSgt, data) {
    var vGr = Math.sqrt(1 / (2 * r));
    if (!isSgt) return vGr;
    var h = data.r_H || FALLBACK.r_H;
    return vGr * Math.sqrt(2 / h);
  }

  function valueAtR(r, data, kind, side) {
    var grid = data.r_grid;
    var key = kind + '_' + side;
    var arr = data[key];
    if (grid && arr && arr.length) {
      var v = interp(r, grid, arr);
      if (v != null) return v;
    }
    return kind === 'g' ? clientG(r, side === 'SGT', data) : clientV(r, side === 'SGT', data);
  }

  function sliderBounds(data) {
    var minIsco = Math.max(data.r_ISCO_SGT || 4.23, data.r_ISCO_GR || 6);
    return { min: minIsco, max: 20, defaultR: data.r_ISCO_GR || 6 };
  }

  function setupSlider(data) {
    var b = sliderBounds(data);
    var slider = $('mc-slider');
    slider.min = b.min;
    slider.max = b.max;
    slider.step = 0.1;
    state.r = b.defaultR;
    slider.value = state.r;
    slider.disabled = false;
    $('mc-slider-wrap').classList.add('active');
    updateSliderUI();
  }

  function tableRow(label, sgt, gr, extraClass) {
    var pct = devPct(sgt, gr);
    var hi = isHighlight(pct) ? ' mc-row-gold' : '';
    return '<tr class="' + (extraClass || '') + hi + '">' +
      '<td class="mc-label">' + label + '</td>' +
      '<td class="mc-val-sgt">' + fmt(sgt, 3) + '</td>' +
      '<td class="mc-val-gr">' + fmt(gr, 3) + '</td>' +
      '<td class="mc-val-dev' + (hi ? ' mc-gold' : '') + '">' + devStr(pct) + '</td>' +
      '</tr>';
  }

  function renderTable(data, extraRows) {
    var tbody = $('mc-table-body');
    var html = '';
    html += tableRow(t('rowIsco'), data.r_ISCO_SGT, data.r_ISCO_GR);
    html += tableRow(t('rowPh'), data.r_ph, 3.0);
    html += tableRow(t('rowH'), data.r_H, 2.0);
    html += tableRow(t('rowTh'), data.T_H_ratio, 1.0);
    if (extraRows) {
      extraRows.forEach(function (row) { html += row; });
    }
    tbody.innerHTML = html;
    $('mc-table-wrap').classList.add('visible');
    var empty = $('mc-empty');
    if (empty) empty.style.display = 'none';
  }

  function updateDetail() {
    if (!state.data) return;
    var r = state.r;
    var d = state.data;
    var gS = valueAtR(r, d, 'g', 'SGT');
    var gG = valueAtR(r, d, 'g', 'GR');
    var vS = valueAtR(r, d, 'v', 'SGT');
    var vG = valueAtR(r, d, 'v', 'GR');
    var pg = devPct(gS, gG);
    var pv = devPct(vS, vG);

    $('mc-detail-g-label').innerHTML = t('detailG', { r: fmt(r, 2) });
    $('mc-detail-v-label').innerHTML = t('detailV', { r: fmt(r, 2) });
    $('mc-g-sgt').textContent = fmt(gS, 4);
    $('mc-g-gr').textContent = fmt(gG, 4);
    $('mc-g-dev').textContent = devStr(pg);
    $('mc-g-dev').className = 'mc-detail-dev' + (isHighlight(pg) ? ' mc-gold' : '');
    $('mc-v-sgt').textContent = fmt(vS, 4);
    $('mc-v-gr').textContent = fmt(vG, 4);
    $('mc-v-dev').textContent = devStr(pv);
    $('mc-v-dev').className = 'mc-detail-dev' + (isHighlight(pv) ? ' mc-gold' : '');
    $('mc-detail').classList.add('visible');
  }

  function updateSliderUI() {
    $('mc-r-display').textContent = t('currentR', { r: fmt(state.r, 2) });
    updateDetail();
  }

  function appendRadiusRows() {
    if (!state.data) return;
    var r = state.r;
    var d = state.data;
    var gS = valueAtR(r, d, 'g', 'SGT');
    var gG = valueAtR(r, d, 'g', 'GR');
    var vS = valueAtR(r, d, 'v', 'SGT');
    var vG = valueAtR(r, d, 'v', 'GR');
    var extra = [
      tableRow(t('rowG', { r: fmt(r, 2) }), gS, gG, 'mc-row-dynamic'),
      tableRow(t('rowV', { r: fmt(r, 2) }), vS, vG, 'mc-row-dynamic')
    ];
    renderTable(d, extra);
  }

  function drawChart(data) {
    var canvas = $('mc-chart');
    var wrap = $('mc-chart-wrap');
    if (!canvas || !wrap) return;
    if (!data.r_grid || !data.g_SGT || !data.g_GR) {
      wrap.classList.remove('visible');
      return;
    }
    wrap.classList.add('visible');
    var dpr = window.devicePixelRatio || 1;
    var w = canvas.clientWidth;
    var h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    var ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);

    var grid = data.r_grid;
    var maxG = 0;
    grid.forEach(function (_, i) {
      maxG = Math.max(maxG, data.g_SGT[i], data.g_GR[i]);
    });
    if (!maxG) maxG = 1;
    var pad = { l: 44, r: 12, t: 12, b: 28 };
    var pw = w - pad.l - pad.r;
    var ph = h - pad.t - pad.b;
    var r0 = grid[0];
    var r1 = grid[grid.length - 1];

    function x(r) { return pad.l + ((r - r0) / (r1 - r0)) * pw; }
    function y(g) { return pad.t + ph - (g / maxG) * ph; }

    ctx.strokeStyle = 'rgba(136,136,160,0.25)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad.l, pad.t + ph);
    ctx.lineTo(pad.l + pw, pad.t + ph);
    ctx.stroke();

    function line(arr, color) {
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      grid.forEach(function (r, i) {
        if (i === 0) ctx.moveTo(x(r), y(arr[i]));
        else ctx.lineTo(x(r), y(arr[i]));
      });
      ctx.stroke();
    }
    line(data.g_GR, '#666680');
    line(data.g_SGT, '#00d4ff');

    if (state.r >= r0 && state.r <= r1) {
      ctx.strokeStyle = GOLD;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      var xr = x(state.r);
      ctx.moveTo(xr, pad.t);
      ctx.lineTo(xr, pad.t + ph);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  function setLoading(on) {
    var btn = $('mc-btn-calc');
    btn.disabled = on;
    btn.classList.toggle('loading', on);
    btn.setAttribute('aria-busy', on ? 'true' : 'false');
  }

  function onCompute() {
    var input = validateInputs();
    if (!input) return;
    var note = $('mc-api-note');
    note.textContent = '';
    note.style.display = 'none';
    setLoading(true);
    fetchMetric(input.M, input.a)
      .then(function (data) {
        state.data = data;
        state.extraRows = false;
        renderTable(data);
        setupSlider(data);
        updateDetail();
        drawChart(data);
        if (data._fallback || (!data.r_grid && !data.g_SGT)) {
          note.textContent = t('fallbackNote');
          note.style.display = 'block';
        }
      })
      .catch(function (err) {
        if (err.code) {
          showFieldErr($('mc-err-m'), err.code === 'INVALID_M' || err.code === 'MISSING_M' ? err.message : '');
          showFieldErr($('mc-err-a'), err.code === 'INVALID_A' ? err.message : '');
          if (err.code !== 'INVALID_M' && err.code !== 'INVALID_A' && err.code !== 'MISSING_M') {
            $('mc-global-err').textContent = err.message;
            $('mc-global-err').style.display = 'block';
          }
          return;
        }
        $('mc-global-err').textContent = err.message || t('errGeneric');
        $('mc-global-err').style.display = 'block';
        state.data = fallbackData(input.M, input.a);
        renderTable(state.data);
        setupSlider(state.data);
        updateDetail();
        note.textContent = t('fallbackNote');
        note.style.display = 'block';
      })
      .finally(function () { setLoading(false); });
  }

  function init() {
    var mass = $('mc-mass');
    var spin = $('mc-spin');
    if (!mass) return;

    $('mc-btn-calc').addEventListener('click', function () {
      $('mc-global-err').style.display = 'none';
      onCompute();
    });

    $('mc-slider').addEventListener('input', function () {
      state.r = parseFloat(this.value);
      updateSliderUI();
      drawChart(state.data);
      if (state.extraRows) appendRadiusRows();
    });

    $('mc-btn-compare-r').addEventListener('click', function () {
      state.extraRows = true;
      appendRadiusRows();
    });

    mass.addEventListener('input', function () { showFieldErr($('mc-err-m'), ''); });
    spin.addEventListener('input', function () { showFieldErr($('mc-err-a'), ''); });

    var params = new URLSearchParams(window.location.search);
    if (params.get('M')) mass.value = params.get('M');
    if (params.get('a')) spin.value = params.get('a');
    if (params.get('run') === '1' || params.get('compute') === '1') {
      onCompute();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
