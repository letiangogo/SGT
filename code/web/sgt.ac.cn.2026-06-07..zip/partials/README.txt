页头 / 页脚片段（参考用）

日常维护：直接改各页面的 HTML 即可，无需跑任何脚本。

若你批量改了 site-header.html 或 site-footer.html，可在项目根目录执行：
  powershell -File scripts/build-site.ps1
将片段同步到带 <!-- sgt:site-header --> 标记的页面。

生产环境不必上传 partials/ 与 scripts/。
