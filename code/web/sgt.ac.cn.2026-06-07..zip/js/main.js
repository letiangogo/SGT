/**
 * SGT 移动端导航切换
 */
(function () {
  function setupNav() {
    var header = document.querySelector('.site-header');
    var nav = document.getElementById('site-nav');
    var toggles = document.querySelectorAll('.nav-toggle');

    toggles.forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!nav) return;
        var open = nav.classList.toggle('open');
        if (header) header.classList.toggle('nav-open', open);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupNav);
  } else {
    setupNav();
  }
})();
