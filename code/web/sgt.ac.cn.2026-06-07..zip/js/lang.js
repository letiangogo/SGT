/**
 * SGT 双语切换 · 持久化至 localStorage，双组按钮同步 · 同步 document.title
 */
(function () {
  var STORAGE_KEY = 'sgt-lang';
  var html = document.documentElement;
  var titleZh = '';
  var titleEn = '';

  function initTitles() {
    var titleEl = document.querySelector('title');
    if (!titleEl) return;

    titleZh = titleEl.getAttribute('data-title-zh') || '';
    titleEn = titleEl.getAttribute('data-title-en') || '';

    if (!titleZh || !titleEn) {
      var raw = (titleEl.textContent || document.title || '').trim();
      var sep = raw.indexOf(' | ');
      if (sep !== -1) {
        titleZh = titleZh || raw.slice(0, sep).trim();
        titleEn = titleEn || raw.slice(sep + 3).trim();
      } else {
        titleZh = titleZh || raw;
        titleEn = titleEn || raw;
      }
    }
  }

  function updateDocumentTitle(lang) {
    if (!titleZh && !titleEn) initTitles();
    if (lang === 'en' && titleEn) {
      document.title = titleEn;
    } else if (titleZh) {
      document.title = titleZh;
    }
  }

  function syncButtons(lang) {
    document.querySelectorAll('[data-lang="zh"]').forEach(function (btn) {
      btn.classList.toggle('active', lang === 'zh');
    });
    document.querySelectorAll('[data-lang="en"]').forEach(function (btn) {
      btn.classList.toggle('active', lang === 'en');
    });
  }

  function applyLangA11y(lang) {
    if (!document.body) return;
    var isEn = lang === 'en';
    document.querySelectorAll('.lang-zh').forEach(function (el) {
      el.hidden = isEn;
      if (isEn) el.setAttribute('aria-hidden', 'true');
      else el.removeAttribute('aria-hidden');
    });
    document.querySelectorAll('.lang-en').forEach(function (el) {
      el.hidden = !isEn;
      if (!isEn) el.setAttribute('aria-hidden', 'true');
      else el.removeAttribute('aria-hidden');
    });
  }

  function detectBrowserLang() {
    var langs = navigator.languages || [navigator.language || ''];
    for (var i = 0; i < langs.length; i++) {
      var code = (langs[i] || '').toLowerCase();
      if (code.indexOf('zh') === 0) return 'zh';
      if (code.indexOf('en') === 0) return 'en';
    }
    return 'zh';
  }

  function setLang(lang, animate) {
    function apply() {
      html.classList.remove('lang-zh', 'lang-en');
      html.classList.add(lang === 'en' ? 'lang-en' : 'lang-zh');
      html.setAttribute('lang', lang === 'en' ? 'en' : 'zh-CN');
      localStorage.setItem(STORAGE_KEY, lang);
      syncButtons(lang);
      updateDocumentTitle(lang);
      applyLangA11y(lang);
    }

    if (animate) {
      html.classList.add('lang-switching');
      setTimeout(function () {
        apply();
        setTimeout(function () { html.classList.remove('lang-switching'); }, 180);
      }, 120);
    } else {
      apply();
    }
  }

  function langFromQuery() {
    try {
      var q = new URLSearchParams(window.location.search).get('lang');
      if (q === 'en' || q === 'zh') return q;
    } catch (e) {}
    return null;
  }

  initTitles();

  var queryLang = langFromQuery();
  var saved = localStorage.getItem(STORAGE_KEY);
  if (queryLang) {
    setLang(queryLang, false);
  } else if (saved === 'en' || saved === 'zh') {
    setLang(saved, false);
  } else {
    setLang(detectBrowserLang(), false);
  }

  document.addEventListener('DOMContentLoaded', function () {
    initTitles();
    var current = html.classList.contains('lang-en') ? 'en' : 'zh';
    updateDocumentTitle(current);
    applyLangA11y(current);

    document.querySelectorAll('[data-lang]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        setLang(btn.getAttribute('data-lang'), true);
      });
    });
  });
})();
