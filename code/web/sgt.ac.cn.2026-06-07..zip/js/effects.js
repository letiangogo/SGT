/**
 * SGT 引力物理科技感动效
 * Canvas 引力场粒子 · 滚动显现 · 导航玻璃态 · 公式高亮
 */
(function () {
  'use strict';

  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isMobile = window.innerWidth < 900;

  /* ========== 注入 Canvas 背景 ========== */
  function initCanvas() {
    if (prefersReduced) return;

    var canvas = document.createElement('canvas');
    canvas.id = 'gravity-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    document.body.prepend(canvas);

    var ctx = canvas.getContext('2d');
    var particles = [];
    var mouse = { x: -9999, y: -9999 };
    var w, h, cx, cy;
    var running = true;

    function resize() {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      cx = w * 0.5;
      cy = h * 0.28;
    }

    function createParticles() {
      particles = [];
      var count = isMobile ? 40 : 90;
      for (var i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          r: Math.random() * 1.2 + 0.4,
          alpha: Math.random() * 0.35 + 0.08
        });
      }
    }

    function drawGrid() {
      ctx.strokeStyle = 'rgba(0, 71, 146, 0.04)';
      ctx.lineWidth = 1;
      var step = 60;
      for (var x = 0; x < w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (var y = 0; y < h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    }

    function drawAttractor() {
      var grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 120);
      grd.addColorStop(0, 'rgba(0, 71, 146, 0.06)');
      grd.addColorStop(0.5, 'rgba(0, 71, 146, 0.02)');
      grd.addColorStop(1, 'rgba(0, 71, 146, 0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(cx, cy, 120, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(0, 71, 146, 0.12)';
      ctx.lineWidth = 1;
      for (var ring = 1; ring <= 3; ring++) {
        ctx.beginPath();
        ctx.arc(cx, cy, ring * 40, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    function updateParticle(p) {
      var ax = cx - p.x;
      var ay = cy - p.y;
      var dist = Math.sqrt(ax * ax + ay * ay) + 80;
      var force = 800 / (dist * dist);
      p.vx += (ax / dist) * force * 0.016;
      p.vy += (ay / dist) * force * 0.016;

      if (mouse.x > 0) {
        var mx = mouse.x - p.x;
        var my = mouse.y - p.y;
        var md = Math.sqrt(mx * mx + my * my) + 60;
        var mf = 400 / (md * md);
        p.vx += (mx / md) * mf * 0.012;
        p.vy += (my / md) * mf * 0.012;
      }

      p.vx *= 0.992;
      p.vy *= 0.992;
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0) p.x = w;
      if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h;
      if (p.y > h) p.y = 0;
    }

    function drawParticle(p) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 71, 146, ' + p.alpha + ')';
      ctx.fill();
    }

    function connectNearby() {
      for (var i = 0; i < particles.length; i++) {
        for (var j = i + 1; j < particles.length; j++) {
          var dx = particles[i].x - particles[j].x;
          var dy = particles[i].y - particles[j].y;
          var d = Math.sqrt(dx * dx + dy * dy);
          if (d < 100) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = 'rgba(0, 71, 146, ' + (0.06 * (1 - d / 100)) + ')';
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
    }

    function frame() {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      drawGrid();
      drawAttractor();
      particles.forEach(function (p) {
        updateParticle(p);
        drawParticle(p);
      });
      connectNearby();
      requestAnimationFrame(frame);
    }

    resize();
    createParticles();
    frame();

    window.addEventListener('resize', function () {
      isMobile = window.innerWidth < 900;
      resize();
      createParticles();
    });

    document.addEventListener('mousemove', function (e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    document.addEventListener('mouseleave', function () {
      mouse.x = -9999;
      mouse.y = -9999;
    });

    document.addEventListener('visibilitychange', function () {
      running = !document.hidden;
      if (running) frame();
    });
  }

  /* ========== 滚动显现 ========== */
  function initReveal() {
    var targets = document.querySelectorAll(
      '.section, .doc-meta, .hero, .formula-block, .table-wrap, .info-box, .liability-block, .declaration-box, .page-title, .metrics-strip, .compare-visual, .cosmo-timeline, .nav-card, .quote-box, .author-line, .advantage-card, .roadmap-step, .roadmap-header, .roadmap-domain, .roadmap-domains, .vision-panel, .roadmap-epigraph, .zkav-spotlight, .zkav-initiative'
    );
    targets.forEach(function (el, i) {
      el.classList.add('reveal');
      el.style.transitionDelay = (i % 6) * 0.06 + 's';
    });

    if (prefersReduced) {
      targets.forEach(function (el) { el.classList.add('revealed'); });
      return;
    }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

    targets.forEach(function (el) { observer.observe(el); });
  }

  /* ========== 导航滚动态 ========== */
  function initHeaderScroll() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    function onScroll() {
      header.classList.toggle('scrolled', window.scrollY > 20);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ========== 首页物理参数 ticker ========== */
  function initHeroTicker() {
    var hero = document.querySelector('.hero');
    if (!hero || !document.querySelector('main .hero')) return;

    var ticker = document.createElement('div');
    ticker.className = 'hero-ticker';
    ticker.setAttribute('aria-hidden', 'true');
    var items =
      '<span class="ticker-item">r<sub>H</sub> = 1.6673 M</span>' +
      '<span class="ticker-item">ISCO = 4.23 M</span>' +
      '<span class="ticker-item">T<sub>H</sub> = 0.866 T<sub>H</sub><sup>GR</sup></span>' +
      '<span class="ticker-item">H(0) = 1.023×10<sup>−1</sup></span>' +
      '<span class="ticker-item">Δt<sub>echo</sub> ≈ 14.3 M</span>' +
      '<span class="ticker-item">G<sub>eff</sub> = G·χ(f)</span>' +
      '<span class="ticker-item">r<sub>ph</sub> = 2.9954 M</span>' +
      '<span class="ticker-item">χ(f) = (1−f)/(1+f²)</span>';
    ticker.innerHTML = '<div class="ticker-track">' + items + items + '</div>';
    hero.appendChild(ticker);
  }

  /* ========== 表格行交互 ========== */
  function initTableHover() {
    document.querySelectorAll('.academic-table tbody tr:not(.cat-row)').forEach(function (row) {
      row.addEventListener('mouseenter', function () {
        row.style.transform = 'translateX(2px)';
      });
      row.addEventListener('mouseleave', function () {
        row.style.transform = '';
      });
    });
  }

  /* ========== 公式块扫描线 ========== */
  function initFormulaScan() {
    document.querySelectorAll('.formula-block').forEach(function (block) {
      if (!block.querySelector('.formula-scan')) {
        var scan = document.createElement('div');
        scan.className = 'formula-scan';
        block.appendChild(scan);
      }
    });
  }

  /* ========== 导航当前页指示器 ========== */
  function initNavIndicator() {
    var nav = document.getElementById('site-nav');
    if (!nav) return;
    var active = nav.querySelector('a.active');
    if (!active) return;

    var indicator = document.createElement('span');
    indicator.className = 'nav-indicator';
    nav.style.position = 'relative';
    active.parentElement.appendChild(indicator);
  }

  /* ========== 对比条入场动画 ========== */
  function initCompareBars() {
    var rows = document.querySelectorAll('.compare-bar');
    if (!rows.length || prefersReduced) return;

    rows.forEach(function (bar) {
      var target = bar.style.width;
      if (!target) {
        var m = (bar.getAttribute('style') || '').match(/width:\s*([^;]+)/i);
        target = m ? m[1].trim() : '100%';
      }
      bar.dataset.targetWidth = target;
      bar.style.width = '0';
    });

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var bar = entry.target;
          bar.style.width = bar.dataset.targetWidth || bar.style.width;
          observer.unobserve(bar);
        }
      });
    }, { threshold: 0.3 });

    rows.forEach(function (bar) { observer.observe(bar); });
  }

  /* ========== 首页页内导航高亮 ========== */
  function initHomeSectionNav() {
    var nav = document.querySelector('.home-section-nav');
    if (!nav || !document.querySelector('.page-home')) return;

    var links = nav.querySelectorAll('.home-section-link[href^="#"]');
    var sections = [];
    links.forEach(function (link) {
      var id = link.getAttribute('href').slice(1);
      var el = document.getElementById(id);
      if (el) sections.push({ id: id, el: el });
    });
    if (!sections.length) return;

    function setActive(id) {
      links.forEach(function (link) {
        link.classList.toggle('active', link.getAttribute('href') === '#' + id);
      });
    }

    if (!prefersReduced) {
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      }, { rootMargin: '-40% 0px -50% 0px', threshold: 0 });
      sections.forEach(function (s) { observer.observe(s.el); });
    }

    links.forEach(function (link) {
      link.addEventListener('click', function (e) {
        var id = link.getAttribute('href').slice(1);
        var target = document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
        history.replaceState(null, '', '#' + id);
        setActive(id);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initCanvas();
    initReveal();
    initHeaderScroll();
    initHeroTicker();
    initTableHover();
    initFormulaScan();
    initNavIndicator();
    initCompareBars();
    initHomeSectionNav();
  });
})();
