# SGT 粒子线实验室 — 泄密安全审计报告

**任务编号：** TASK-WEB-PARTICLELINE-001（紧急调整）  
**审计范围：** `solver/js/particle-line/`、`solver/js/demos/particle-line-lab.js`、`solver/css/particle-line-lab.css`、`lab/particle-line/`  
**审计日期：** 2026-06-06  
**结论：** ✅ 调整后前端代码符合安全标准（零精确公式、零 ODE 数据、零内部参数名）

---

## 一、泄密清单逐项检查

| 检查项 | 涉密内容 | 调整前 | 调整后 |
|--------|----------|:------:|:------:|
| U(f) 解析形式 | tanh 函数表达式 | 未出现 | 未出现 |
| 弹性常数幂律 | C_rr ∝ χ^{-0.75} 等 | **涉密**（`elasticConstants` 幂律） | ✅ 已删除 |
| K 和 f_c 数值 | K=0.050±0.002, f_c=0.800±0.010 | 未出现 | 未出现 |
| W 协变形式 | 3+1 弹性能密度展开 | 未出现 | 未出现 |
| Ω-A1 完整算法 | 边界条件、迭代逻辑 | 未出现 | 未出现 |
| Δf 与 f_c 关系 | Δf 由 f_c 决定的函数 | 未出现 | 未出现 |
| 36 点 f(r) 数据 | R_ODE 和 F_ODE 数组 | **涉密**（36 点样条插值） | ✅ 已删除 |
| χ(f) 精确公式 | (1-f)/(1+f²) | **涉密**（`chiOfF`） | ✅ 替换为 `chiFuzzy(f)=1-f` |
| A_eff 精确公式 | (1-f)(1-f/2)² | **涉密**（`AEffOfF`） | ✅ 已删除 |
| κ_p=G/2 | 0.5 的耦合常数 | **涉密**（`KAPPA_P=0.5`、`V_eff=0.5*f`） | ✅ 已删除 |
| V_eff 精确公式 | 0.5*f | **涉密**（`VEff`） | ✅ 替换为归一化 `potentialWellDepth()` |
| 弹性常数名称 | C_rr, C_θθ 等 | **涉密**（UI 与 `elasticConstants`） | ✅ 替换为径向锁定 / 切向软化 |
| f_c 临界值 | 0.8 | 未出现 | 未出现 |

---

## 二、调整动作摘要

### 1. `solver/js/particle-line/physics.js`（重写）

| 删除项 | 替换项 |
|--------|--------|
| `R_ODE`, `F_ODE` 36 点数组 | — |
| `chiOfF(f) = (1-f)/(1+f²)` | `chiFuzzy(f) = 1 - f` |
| `AEffOfF(f) = (1-f)(1-f/2)²` | —（不再导出） |
| `VEff(f) = 0.5 * f` | `potentialWellDepth() = 1.0` |
| `fOfR(r)` 样条插值 | `fFuzzy(r) = 1/(1+0.8r)` |
| `elasticConstants(f)` 含 C_rr/C_θθ 幂律 | `strongFieldResponse(f)` → radialLock / tangentialSoft |
| 视界半径 1.668 | `coreRadiusFuzzy(f)` 模糊近似 |

### 2. `solver/js/particle-line/scene.js`

- 所有 `fOfR` → `fFuzzy`
- 指标输出：`aEff`/`crr`/`ctt` → `radialLock`/`tangentialSoft`
- 强场线数 36 → 32（避免与 ODE 点数关联）

### 3. `solver/js/demos/particle-line-lab.js`

- 指标面板：移除 A_eff、C_rr、C_θθ；新增介质响应、径向锁定、切向软化
- 移除 κ_p=0.50 滑块标签
- 势阱图标签 `V_eff(x)` → `势阱(归一)` / `Well (norm.)`
- 免责声明改为「定性教学 · 模糊近似 · 非精确 SGT 公式」

### 4. 文档

- `lab/particle-line/README.md` — 移除精确公式与 ODE 描述
- `lab/particle-line/index.html` — 页脚移除 Ω-A1 表述

---

## 三、调整后安全标准验证

| 标准 | 状态 | 说明 |
|------|:----:|------|
| JS 零 SGT 精确公式 | ✅ | 无 `(1-f)/(1+f²)`、`(1-f/2)²`、`0.5*f` 等 |
| JS 零 SGT 精确数据 | ✅ | 无 R_ODE/F_ODE 或 1.6684 剖面表 |
| JS 零 SGT 内部参数名 | ✅ | 无 C_rr、C_θθ、κ_p、A_eff、V_eff 标识符 |
| 展示定性正确 | ✅ | 轴向撑开、势阱、力线、强场锁定方向保持 |

---

## 四、残留说明（非粒子线模块）

以下文件仍含 **Ω-A1** 等公开产品表述，**不在本次粒子线前端 JS 审计范围内**（Solver 主站、框架页、API 回退文案等）：

- `solver/index.html`、`solver/js/solver-app.js`（API 不可用回退提示）
- `lab/index.html`（实验室门户总述）
- `framework.html`、`audit.html`、`TECHNICAL.md`

粒子线模块本身的前端 JS **未引用**上述后端或文档内容。

---

## 五、功能验证清单

| 预设模式 | 预期行为 | 验证 |
|----------|----------|:----:|
| 单条粒子线 | 粒子线 + 张力/力线切换 | ✅ 代码路径完整 |
| 双粒子线元 | 双粒子 + 势阱剖面图 | ✅ `dualWellProfile` + 图表 |
| 球对称天体 | 辐射状线束 + 径向/切向箭头 | ✅ `_buildSphere` |
| 强场极限 | 核心球 + 饱和线束 + 锁定指标 | ✅ `strongFieldResponse` |
| 自由探索 | 滑块调 f / 线长 / 粒子数 | ✅ `free` preset |

建议在浏览器打开 `/lab/particle-line/` 或 `/solver/#thought-particle-line` 目视确认 WebGL 渲染与五预设切换。

---

**审计人：** CURSOR 团队  
**交付对象：** 教练员 A
