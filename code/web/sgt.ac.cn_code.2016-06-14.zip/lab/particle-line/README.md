# SGT 粒子线思想实验 — WEB 实验室

**任务编号：** TASK-WEB-PARTICLELINE-001  
**定位：** SGT-Pure 纯净范式 · 粒子线轴向撑开 · 交互式 3D 可视化（定性 / 模糊近似）

## 访问入口

| 入口 | URL |
|------|-----|
| 独立实验室页 | `/lab/particle-line/` |
| Solver 工作台 | `/solver/#thought-particle-line` |

## 目录结构

```
solver/js/particle-line/physics.js   — 模糊化介质响应、f(r) 近似、势阱归一化
solver/js/particle-line/scene.js     — Three.js 四模式场景
solver/js/demos/particle-line-lab.js — UI 与控制面板
solver/css/particle-line-lab.css     — 深空主题样式
lab/particle-line/index.html         — 独立部署页
lab/particle-line/SECURITY-AUDIT.md  — 泄密安全审计报告
```

## 预设场景

1. **单条粒子线** — 轴向撑开、张力梯度、力线
2. **双粒子线元** — 量子引力原子、归一化势阱剖面
3. **球对称天体** — 辐射状粒子线集合、径向/切向对比
4. **强场极限** — f→1 径向锁定、切向软化示意
5. **自由探索** — 自定义 f、线长、粒子数

## 物理实现（内嵌，无需后端）

前端仅使用**定性正确、数值模糊**的近似，不含精确 SGT 公式或 ODE 剖面数据：

- 介质响应：`chiFuzzy(f) ≈ 1 − f`
- 径向剖面：`fFuzzy(r) ≈ 1 / (1 + 0.8r)`
- 势阱深度：归一化常数（不暴露耦合参数）
- 强场模式：径向锁定 / 切向软化定性指标

## 可选后端 API（未来）

任务书预留端点（当前前端已内嵌模糊计算，可不部署后端）：

- `POST /api/particle-line/f-profile`
- `POST /api/particle-line/tension`

## 部署

1. 将 `solver/js/particle-line/`、`solver/js/demos/particle-line-lab.js`、`solver/css/particle-line-lab.css` 与 `lab/particle-line/index.html` 同步到站点。
2. 确保 `solver/js/vendor/three.min.js` 与 `OrbitControls.js` 可访问（与 3D 黑洞模块共用）。
3. Nginx 无需额外反代；纯静态资源。

## 依赖

- Three.js r128（项目 vendor）
- OrbitControls（项目 vendor）
- 现代浏览器 WebGL 2

## 评估对照

| 项目 | 状态 |
|------|------|
| 四预设 + 自由探索 | ✅ |
| 位移场 / 张力 / 力线切换 | ✅ |
| f、介质响应实时读数 | ✅ |
| 双粒子势阱剖面 | ✅ |
| 强场径向锁定 / 切向软化 | ✅ |
| 深空主题 | ✅ |
| 前端零精确 SGT 公式与 ODE 数据 | ✅（见 SECURITY-AUDIT.md） |
