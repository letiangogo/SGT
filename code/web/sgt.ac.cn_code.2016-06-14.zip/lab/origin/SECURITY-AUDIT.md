# SGT 理论起源实验室 — 泄密安全审计报告

**任务编号：** TASK-WEB-ORIGIN-001  
**审计范围：** `solver/js/origin/`、`solver/js/demos/origin-lab.js`、`solver/css/origin-lab.css`、`lab/origin/`  
**审计日期：** 2026-06-06  
**结论：** ✅ 无 SGT 机密泄露；全部为模糊化定性函数

---

## 泄密清单

| 检查项 | 状态 |
|--------|:----:|
| 弹性常数及幂律 | ✅ 未出现 |
| f(r) / 36 点 ODE | ✅ 未出现 |
| χ(f) 精确公式 | ✅ 未出现 |
| K / f_c 数值 | ✅ 未出现 |
| U(f) tanh 形式 | ✅ 未出现 |
| Ω-A1 算法 | ✅ 未出现 |
| SGT 宪法精确参数 | ✅ 未出现 |

---

## 前端物理 API（模糊化）

| 函数 | 说明 |
|------|------|
| `displacementMagnitude` | 1/r² 定性衰减，无精确弹性常数 |
| `pressureAtPoint` | 挤出程度代理 |
| `pressureGradientDir` | 由球心向外辐射方向 |
| `gradientStrength` | 归一化力线强度 |

---

## 页面声明

- 琥珀色边框 **⚠️ 重要声明** 区块位于 3D 视图上方
- 明确标注「已被张力梯度模型取代」
- 底部理论演化对比：压力梯度 vs 张力梯度

---

**审计人：** CURSOR 团队
