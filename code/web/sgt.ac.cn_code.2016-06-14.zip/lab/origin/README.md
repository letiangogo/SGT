# SGT 理论起源 — 初始物理图景 WEB 实验室

**任务编号：** TASK-WEB-ORIGIN-001  
**定位：** SGT 理论演化史起点 · 挤出-回弹模型（历史教学 · 已被取代）

## 访问入口

| 入口 | URL |
|------|-----|
| 独立实验室页 | `/lab/origin/` |
| Solver 工作台 | `/solver/#thought-origin` |

## 重要声明

本实验室展示 **2026 年 5 月 SGT 诞生初期的初始物理图景**（物质挤出介质 → 梯度压力）。该模型已被 **介质张力梯度模型（粒子线轴向撑开）** 取代。页面顶部有琥珀色边框的显著声明。

## 目录结构

```
solver/js/origin/physics.js     — 模糊化挤出变形与压力梯度
solver/js/origin/scene.js       — Three.js 球体挤出介质场景
solver/js/demos/origin-lab.js   — UI、声明、理论对比
solver/css/origin-lab.css       — 深空 + 起源暖色主题
lab/origin/index.html           — 独立部署页
lab/origin/SECURITY-AUDIT.md    — 泄密安全审计
```

## 交互功能

- 物质质量滑块 → 挤出程度 / 力线密度
- 预设：小质量天体 / 大质量天体
- 显示：全部 / 介质变形 / 压力梯度力线 / 颜色映射
- 底部：初始模型 vs 当前 SGT-Pure 模型对比示意

## 部署

1. 同步 `solver/js/origin/`、`origin-lab.js`、`origin-lab.css`、`lab/origin/` 到站点。
2. 依赖 `three.min.js`、`OrbitControls.js`（项目 vendor）。
3. 纯静态，无需后端。

## 评估

| 项目 | 状态 |
|------|:----:|
| 3D 网格变形 + 力线 | ✅ |
| 质量调节实时响应 | ✅ |
| 重要声明显著标注 | ✅ |
| 理论演化对比 | ✅ |
| 安全审计 | ✅ |
