# SGT 热力学思想实验 — WEB 实验室

**任务编号：** TASK-WEB-THERMO-001  
**定位：** 介质是舞台 · 物质是演员 · 热力是节目 · 交互式 3D 可视化（定性 / 模糊近似）

## 访问入口

| 入口 | URL |
|------|-----|
| 独立实验室页 | `/lab/thermo/` |
| Solver 工作台 | `/solver/#thought-thermo` |

## 目录结构

```
solver/js/thermo/physics.js      — 模糊化张力场、动能、熵、热传导
solver/js/thermo/scene.js        — Three.js 四场景动画
solver/js/demos/thermo-lab.js    — UI 与控制面板
solver/css/thermo-lab.css        — 深空主题样式
lab/thermo/index.html            — 独立部署页
lab/thermo/SECURITY-AUDIT.md     — 泄密安全审计报告
```

## 四个预设场景

1. **温度的本质** — 粒子速度滑块 → 舞台局部张力变红
2. **熵的本质** — 有序/无序态切换 → 构型数（分布均匀度）
3. **热传导** — 冷热分区 + 张力梯度驱动扩散 + 热流箭头
4. **Hawking 温度** — 视界附近弹性振动与特征频率（定性）

## 物理实现（内嵌，无需后端）

- 介质张力：粒子邻近 + 逆距离模糊衰减
- 温度：归一化平均动能（无玻尔兹曼常数）
- 熵：空间分布均匀度代理（无精确 Ω 公式）
- Hawking：归一化振动频率（无弹性常数幂律）

## 部署

1. 同步 `solver/js/thermo/`、`solver/js/demos/thermo-lab.js`、`solver/css/thermo-lab.css`、`lab/thermo/` 到站点。
2. 确保 `solver/js/vendor/three.min.js` 与 `OrbitControls.js` 可访问。
3. 纯静态资源，无需后端。

## 依赖

- Three.js r128（项目 vendor）
- OrbitControls（项目 vendor）
- 现代浏览器 WebGL

## 评估对照

| 项目 | 状态 |
|------|------|
| 四预设场景 | ✅ |
| 舞台网格 + 粒子 + 热流 | ✅ |
| 参数实时响应 | ✅ |
| 深空主题 | ✅ |
| 前端零精确 SGT 公式 | ✅（见 SECURITY-AUDIT.md） |
