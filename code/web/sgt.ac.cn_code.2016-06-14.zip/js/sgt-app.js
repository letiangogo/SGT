/**
 * SGT 全站调度 — 统一注入 AI 精灵等资源
 */
(function (global) {
  'use strict';

  var MARKED = 'https://cdn.jsdelivr.net/npm/marked@12.0.2/marked.min.js';
  var KATEX_JS = 'https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js';
  var KATEX_CSS = 'https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css';

  function siteBase() {
    var script = document.currentScript;
    if (script && script.src) {
      return script.src.replace(/\\/g, '/').replace(/js\/sgt-app\.js(\?.*)?$/, '');
    }
    var path = (global.location.pathname || '').replace(/\\/g, '/');
    return /\/solver\//i.test(path) ? '../' : '';
  }

  function isAiDedicatedPage() {
    var path = (global.location.pathname || '').replace(/\\/g, '/');
    return /\/ai\.html$/i.test(path);
  }

  function ensureCss(href, id) {
    if (id && document.getElementById(id)) return;
    if ([].some.call(document.querySelectorAll('link[rel="stylesheet"]'), function (l) {
      return l.href === href || l.getAttribute('href') === href;
    })) return;
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = href;
    if (id) link.id = id;
    document.head.appendChild(link);
  }

  function loadScript(src, crossOrigin) {
    return new Promise(function (resolve, reject) {
      var norm = src.replace(/\\/g, '/');
      var exists = [].some.call(document.querySelectorAll('script[src]'), function (s) {
        var ssrc = (s.src || '').replace(/\\/g, '/');
        return ssrc === norm || s.getAttribute('src') === src;
      });
      if (exists) {
        resolve();
        return;
      }
      var el = document.createElement('script');
      el.src = src;
      if (crossOrigin) el.crossOrigin = crossOrigin;
      el.onload = function () { resolve(); };
      el.onerror = function () { reject(new Error('Failed to load ' + src)); };
      document.body.appendChild(el);
    });
  }

  function tutorMarkup(base) {
    var aiHref = base + 'ai.html';
    return '<div id="sgt-tutor-root" class="sgt-tutor-root" aria-live="polite">' +
      '<button type="button" class="sgt-tutor-fab" id="sgt-tutor-fab"' +
      ' aria-label="SGT AI 精灵" aria-expanded="false" title="SGT AI 精灵">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">' +
      '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>' +
      '<circle cx="9" cy="11.5" r="1" fill="currentColor" stroke="none"/>' +
      '<circle cx="12.5" cy="11.5" r="1" fill="currentColor" stroke="none"/>' +
      '<circle cx="16" cy="11.5" r="1" fill="currentColor" stroke="none"/>' +
      '</svg></button>' +
      '<div class="sgt-tutor-panel" id="sgt-tutor-panel" role="dialog" aria-labelledby="sgt-tutor-title">' +
      '<header class="sgt-tutor-header">' +
      '<span class="sgt-tutor-title" id="sgt-tutor-title">' +
      '<span class="lang-zh">SGT AI 精灵</span><span class="lang-en">SGT AI Genie</span></span>' +
      '<div class="sgt-tutor-header-actions">' +
      '<a href="' + aiHref + '" class="sgt-tutor-icon-btn sgt-tutor-expand" id="sgt-tutor-expand"' +
      ' title="全屏工作台" aria-label="全屏工作台">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' +
      '<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></a>' +
      '<button type="button" class="sgt-tutor-icon-btn" id="sgt-tutor-new"' +
      ' title="归档并开始新话题" aria-label="归档并开始新话题">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' +
      '<path d="M1 4v6h6"/><path d="M23 20v-6h-6"/>' +
      '<path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg></button>' +
      '<button type="button" class="sgt-tutor-icon-btn" id="sgt-tutor-close" aria-label="关闭">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">' +
      '<path d="M18 6L6 18M6 6l12 12"/></svg></button></div></header>' +
      '<p class="sgt-tutor-err" id="sgt-tutor-err" role="alert"></p>' +
      '<div class="sgt-tutor-messages" id="sgt-tutor-messages"></div>' +
      '<div class="sgt-tutor-input-wrap"><div class="sgt-tutor-input-row">' +
      '<textarea class="sgt-tutor-input" id="sgt-tutor-input" rows="1" autocomplete="off" maxlength="500"' +
      ' data-placeholder-zh="输入问题（最多500字）" data-placeholder-en="Ask (max 500 chars)"></textarea>' +
      '<button type="button" class="sgt-tutor-send" id="sgt-tutor-send" aria-label="发送">' +
      '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' +
      '<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button></div>' +
      '<p class="sgt-tutor-hint">' +
      '<span class="lang-zh"><a href="' + aiHref + '">全屏工作台</a> · 6 轮/500 字上限 · 重置归档至本地</span>' +
      '<span class="lang-en"><a href="' + aiHref + '">Full workspace</a> · 6 turns / 500 chars max · Reset archives locally</span>' +
      '</p><p class="sgt-tutor-char-count" id="sgt-tutor-char-count" aria-live="polite">0/500</p></div></div></div>';
  }

  function injectTutor(base) {
    if (document.getElementById('sgt-tutor-root')) return;
    var host = document.createElement('div');
    host.innerHTML = tutorMarkup(base);
    document.body.appendChild(host.firstElementChild);
  }

  function bootAi(base) {
    ensureCss(base + 'css/sgt-tutor.css', 'sgt-tutor-css');
    ensureCss(KATEX_CSS, 'sgt-katex-css');
    injectTutor(base);
    return loadScript(base + 'js/sgt-ai-store.js')
      .then(function () { return loadScript(MARKED, 'anonymous'); })
      .then(function () { return loadScript(KATEX_JS, 'anonymous'); })
      .then(function () { return loadScript(base + 'js/sgt-tutor-md.js'); })
      .then(function () { return loadScript(base + 'js/sgt-ai-engine.js'); })
      .then(function () { return loadScript(base + 'js/sgt-tutor.js'); });
  }

  function boot(opts) {
    if (isAiDedicatedPage()) return Promise.resolve();
    var base = siteBase();
    var script = document.currentScript;
    var aiOn = opts && opts.ai === false ? false : !(script && script.getAttribute('data-ai') === 'false');
    if (!aiOn) return Promise.resolve();
    return bootAi(base).catch(function (err) {
      if (global.console && global.console.error) {
        global.console.error('[SgtApp] AI boot failed:', err);
      }
    });
  }

  global.SgtApp = { boot: boot, base: siteBase, isAiPage: isAiDedicatedPage };

  boot();
})(typeof window !== 'undefined' ? window : this);
