/**
 * SGT 移动端导航切换 + 顶栏高度同步（首页观测带动画条贴齐导航）
 */
(function () {
  function syncSiteHeaderHeight() {
    var header = document.querySelector('.site-header');
    if (!header) return;
    if (document.body.classList.contains('page-home')) {
      document.documentElement.style.setProperty('--home-header-stack-h', header.offsetHeight + 'px');
    }
  }

  function setupHeaderHeightSync() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    syncSiteHeaderHeight();

    if (typeof ResizeObserver !== 'undefined') {
      var ro = new ResizeObserver(syncSiteHeaderHeight);
      ro.observe(header);
    } else {
      window.addEventListener('resize', syncSiteHeaderHeight);
    }

    window.addEventListener('orientationchange', syncSiteHeaderHeight);
  }

  function setupNav() {
    var header = document.querySelector('.site-header');
    var nav = document.getElementById('site-nav');
    var toggles = document.querySelectorAll('.nav-toggle');
    if (!header || !nav) return;

    var panel = header.querySelector('.header-right');

    function isMobileNavMode() {
      var en = document.documentElement.classList.contains('lang-en');
      return window.matchMedia(en ? '(max-width: 980px)' : '(max-width: 900px)').matches;
    }

    function setNavOpen(open) {
      nav.classList.toggle('open', open);
      header.classList.toggle('nav-open', open);
      toggles.forEach(function (btn) {
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
      syncSiteHeaderHeight();
    }

    function closeNav() {
      if (header.classList.contains('nav-open')) setNavOpen(false);
    }

    toggles.forEach(function (btn) {
      btn.setAttribute('aria-expanded', 'false');
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        setNavOpen(!header.classList.contains('nav-open'));
      });
    });

    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', closeNav);
    });

    document.addEventListener('click', function (e) {
      if (!header.classList.contains('nav-open')) return;
      if (panel && panel.contains(e.target)) return;
      if (e.target.closest('.nav-toggle')) return;
      closeNav();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeNav();
    });

    window.addEventListener('resize', function () {
      if (!isMobileNavMode()) closeNav();
    });
  }

  function boot() {
    setupNav();
    setupHeaderHeightSync();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
