/**
 * SGT AI 精灵 — 专题页（ai.html）
 */
(function () {
  'use strict';

  var store = window.SgtAiStore;
  var chat = null;
  var viewingArchiveId = null;

  function $(sel) { return document.querySelector(sel); }

  function isEn() {
    return document.documentElement.classList.contains('lang-en');
  }

  function t(zh, en) { return isEn() ? en : zh; }

  function formatTime(ts) {
    try {
      return new Date(ts).toLocaleString(isEn() ? 'en-GB' : 'zh-CN', {
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
      });
    } catch (e) {
      return '';
    }
  }

  var inputRo = null;

  function syncMobileLayout() {
    if (window.innerWidth > 900) {
      document.documentElement.style.removeProperty('--sgt-ai-header-h');
      document.documentElement.style.removeProperty('--sgt-ai-input-h');
      return;
    }
    var header = document.querySelector('.site-header');
    if (header) {
      document.documentElement.style.setProperty('--sgt-ai-header-h', header.offsetHeight + 'px');
    }
    var inputWrap = $('#sgt-ai-input-wrap');
    if (inputWrap && !inputWrap.classList.contains('is-hidden')) {
      document.documentElement.style.setProperty('--sgt-ai-input-h', inputWrap.offsetHeight + 'px');
    }
    var messages = $('#sgt-ai-messages');
    if (messages) {
      var nearBottom = messages.scrollHeight - messages.scrollTop - messages.clientHeight < 120;
      if (nearBottom) messages.scrollTop = messages.scrollHeight;
    }
  }

  function watchInputWrapResize() {
    if (!window.ResizeObserver) return;
    var inputWrap = $('#sgt-ai-input-wrap');
    if (!inputWrap) return;
    if (inputRo) inputRo.disconnect();
    inputRo = new ResizeObserver(function () {
      syncMobileLayout();
    });
    inputRo.observe(inputWrap);
  }

  function setDrawerOpen(open) {
    document.body.classList.toggle('sgt-ai-drawer-open', !!open);
    var backdrop = $('#sgt-ai-drawer-backdrop');
    var toggle = $('#sgt-ai-history-toggle');
    if (backdrop) {
      backdrop.hidden = !open;
      backdrop.setAttribute('aria-hidden', open ? 'false' : 'true');
    }
    if (toggle) toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  function closeDrawer() {
    setDrawerOpen(false);
  }

  function setViewMode(mode) {
    var banner = $('#sgt-ai-readonly-banner');
    var inputWrap = $('#sgt-ai-input-wrap');
    var newBtn = $('#sgt-ai-new');
    var historyBtn = $('#sgt-ai-history-toggle');
    if (mode === 'archive') {
      if (banner) banner.hidden = false;
      if (inputWrap) inputWrap.classList.add('is-hidden');
      if (chat) chat.setReadOnly(true);
      if (newBtn) newBtn.hidden = true;
    } else {
      if (banner) banner.hidden = true;
      if (inputWrap) inputWrap.classList.remove('is-hidden');
      if (chat) chat.setReadOnly(false);
      if (newBtn) newBtn.hidden = false;
    }
    if (historyBtn) historyBtn.hidden = false;
    closeDrawer();
    syncMobileLayout();
  }

  function renderArchiveList() {
    var list = $('#sgt-ai-archive-list');
    if (!list || !store) return;
    var items = store.listArchives();
    if (!items.length) {
      list.innerHTML = '<li class="sgt-ai-archive-empty">' +
        '<span class="lang-zh">暂无临时归档</span>' +
        '<span class="lang-en">No archived chats yet</span></li>';
      return;
    }
    list.innerHTML = items.map(function (item) {
      var active = viewingArchiveId === item.id ? ' is-active' : '';
      return '<li class="sgt-ai-archive-item' + active + '" data-id="' + item.id + '">' +
        '<button type="button" class="sgt-ai-archive-btn">' +
        '<span class="sgt-ai-archive-title">' + escapeHtml(item.title) + '</span>' +
        '<span class="sgt-ai-archive-meta">' + formatTime(item.archivedAt) +
        ' · ' + item.messageCount + t(' 条', ' msgs') + '</span></button>' +
        '<button type="button" class="sgt-ai-archive-del" data-del="' + item.id + '" aria-label="' +
        t('删除归档', 'Delete archive') + '">×</button></li>';
    }).join('');

    list.querySelectorAll('.sgt-ai-archive-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var li = btn.closest('.sgt-ai-archive-item');
        if (!li) return;
        openArchive(li.getAttribute('data-id'));
      });
    });
    list.querySelectorAll('.sgt-ai-archive-del').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = btn.getAttribute('data-del');
        if (!id || !confirm(t('确定删除这条临时归档？', 'Delete this archived chat?'))) return;
        store.deleteArchive(id);
        if (viewingArchiveId === id) showCurrentChat();
        renderArchiveList();
      });
    });
  }

  function escapeHtml(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function updateSidebarCurrent() {
    var curBtn = $('#sgt-ai-nav-current');
    if (curBtn) curBtn.classList.toggle('is-active', !viewingArchiveId);
  }

  function openArchive(id) {
    if (!store || !chat) return;
    var item = store.getArchive(id);
    if (!item) return;
    viewingArchiveId = id;
    setViewMode('archive');
    updateSidebarCurrent();
    chat.setMessages(item.messages, { skipPersist: true });
    var titleEl = $('#sgt-ai-toolbar-title');
    if (titleEl) titleEl.textContent = item.title;
    renderArchiveList();
  }

  function showCurrentChat() {
    viewingArchiveId = null;
    setViewMode('current');
    updateSidebarCurrent();
    var titleEl = $('#sgt-ai-toolbar-title');
    if (titleEl) {
      titleEl.innerHTML = '<span class="lang-zh">当前对话</span><span class="lang-en">Current chat</span>';
    }
    if (!store || !chat) return;
    var cur = store.getCurrent();
    chat.setMessages(cur.messages, { skipPersist: true });
    renderArchiveList();
  }

  function startNewChat() {
    if (!store || !chat) return;
    if (viewingArchiveId) {
      showCurrentChat();
    }
    if (chat.getMessages().length) {
      store.archiveMessages(chat.getMessages(), { startedAt: store.getCurrent().ts });
    }
    chat.resetTopic(false);
    store.saveCurrent({ messages: [], isOpen: false });
    renderArchiveList();
  }

  function initChat() {
    if (!store || !window.SgtAiEngine) return;
    var cur = store.getCurrent();
    chat = window.SgtAiEngine.create({
      messagesEl: '#sgt-ai-messages',
      inputEl: '#sgt-ai-input',
      sendBtnEl: '#sgt-ai-send',
      errorEl: '#sgt-ai-err',
      initialMessages: cur.messages,
      welcomeHtml: '<div class="sgt-ai-page-welcome">' +
        '<h2 class="lang-zh">SGT AI 精灵</h2><h2 class="lang-en">SGT AI Genie</h2>' +
        '<p class="lang-zh">基于 SGT 知识库的学术问答助手。对话与归档仅保存在本机浏览器，不会同步至云端。因算力资源有限，每段对话最多 <strong>6 轮</strong>问答，单次输入不超过 <strong>500 字</strong>，请尽量简明精准。</p>' +
        '<p class="lang-en">Academic Q&amp;A grounded in the SGT knowledge base. Chats and archives stay local in your browser only. Due to limited resources: max <strong>6 turns</strong> per chat and <strong>500 characters</strong> per message — please be concise.</p></div>',
      charCountEl: '#sgt-ai-char-count',
      onPersist: function (msgs) {
        if (viewingArchiveId) return;
        store.saveCurrent({ messages: msgs, isOpen: false });
      },
      onArchive: function (msgs) {
        store.archiveMessages(msgs, { startedAt: store.getCurrent().ts });
        renderArchiveList();
      },
      onReset: function () {
        if (!viewingArchiveId) store.saveCurrent({ messages: [], isOpen: false });
      },
      onInputResize: syncMobileLayout,
      onReply: function () {
        renderArchiveList();
        syncMobileLayout();
      }
    });
  }

  function init() {
    initChat();
    renderArchiveList();
    showCurrentChat();

    var curNav = $('#sgt-ai-nav-current');
    if (curNav) curNav.addEventListener('click', showCurrentChat);

    var newBtn = $('#sgt-ai-new');
    if (newBtn) newBtn.addEventListener('click', startNewChat);

    var backBtn = $('#sgt-ai-back-current');
    if (backBtn) backBtn.addEventListener('click', showCurrentChat);

    var historyToggle = $('#sgt-ai-history-toggle');
    if (historyToggle) {
      historyToggle.addEventListener('click', function () {
        setDrawerOpen(!document.body.classList.contains('sgt-ai-drawer-open'));
      });
    }

    var drawerBackdrop = $('#sgt-ai-drawer-backdrop');
    if (drawerBackdrop) {
      drawerBackdrop.addEventListener('click', closeDrawer);
    }

    window.addEventListener('beforeunload', function () {
      if (store && chat && !viewingArchiveId) {
        store.saveCurrent({ messages: chat.getMessages(), isOpen: false });
      }
    });

    syncMobileLayout();
    watchInputWrapResize();
    window.addEventListener('resize', syncMobileLayout);
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', syncMobileLayout);
    }
    requestAnimationFrame(function () { syncMobileLayout(); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
