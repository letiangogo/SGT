/**

 * SGT AI 精灵 — AI 表格预处理 + marked(GFM) + KaTeX

 * 依赖：marked (CDN)、katex (CDN，可选)

 */

(function (global) {

  'use strict';



  var DEFAULT_COLS = 4;



  if (global.marked && global.marked.setOptions) {

    global.marked.setOptions({

      gfm: true,

      breaks: false,

      headerIds: false,

      mangle: false

    });

  }



  function escapeHtml(s) {

    return String(s)

      .replace(/&/g, '&amp;')

      .replace(/</g, '&lt;')

      .replace(/>/g, '&gt;')

      .replace(/"/g, '&quot;');

  }



  function padRow(row, n) {

    var r = row.slice();

    while (r.length < n) r.push('');

    return r.slice(0, n);

  }



  function isHeaderLabel(cell) {

    return /^(对比维度|测试场景|指标|维度|场景)/.test(String(cell || '').trim());

  }



  function isPipeGarbage(t) {

    return /^\|+\s*:?\s*$/.test(t) || /^\|+\s*$/.test(t);

  }



  function splitTabFields(text) {

    return String(text || '').split('\t').map(function (c) {

      return c.replace(/\s+/g, ' ').trim();

    }).filter(function (c) {

      return c.length > 0 && c !== ':';

    });

  }



  function rowToPipe(row) {

    return '| ' + row.map(function (c) { return c.replace(/\|/g, '\\|'); }).join(' | ') + ' |';

  }



  function rowsToGfmTable(rows, colCount) {

    if (!rows.length) return '';

    var lines = [];

    var n = colCount || rows[0].length;

    rows.forEach(function (row, idx) {

      lines.push(rowToPipe(padRow(row, n)));

      if (idx === 0) {

        lines.push('| ' + Array(n).fill('---').join(' | ') + ' |');

      }

    });

    return lines.join('\n');

  }



  function isSeparatorSegment(seg) {

    var inner = String(seg || '').trim().replace(/^\|+/, '').replace(/\|+$/, '');

    if (!inner) return true;

    var parts = inner.split('|').map(function (c) { return c.trim(); });

    return parts.length >= 2 && parts.every(function (c) {

      return /^[\-:\s]+$/.test(c);

    });

  }



  function parsePipeRowSegment(seg) {

    var s = String(seg || '').trim();

    if (!s || isSeparatorSegment(s)) return null;

    if (s.charAt(0) !== '|') s = '|' + s;

    if (s.charAt(s.length - 1) !== '|') s = s + '|';

    var cells = s.split('|').slice(1, -1).map(function (c) { return c.trim(); });

    return cells.length >= 2 ? cells : null;

  }



  /** AI 常见：整段 pipe 表挤在一行，行间用 || 分隔 */

  function expandCompactPipeLine(line) {

    var tableStart = line.search(/\|\s*对比维度\s*\|/);

    if (tableStart < 0) {

      tableStart = line.search(/\|[^|\n]+\|[^|\n]+\|/);

    }

    if (tableStart < 0) return line;



    var intro = line.slice(0, tableStart).trim();

    var rest = line.slice(tableStart);

    var tail = '';



    var tailMatch = rest.match(/\|\s*\*\*(?:关键说明|进一步探索)/);

    if (tailMatch) {

      var idx = rest.indexOf(tailMatch[0]);

      tail = rest.slice(idx + 1);

      rest = rest.slice(0, idx);

    }



    var segments = rest.split(/\s*\|\|\s*/);

    var rows = [];

    segments.forEach(function (seg) {

      var row = parsePipeRowSegment(seg);

      if (row) rows.push(row);

    });



    if (rows.length < 2) return line;



    var colCount = rows[0].length;

    rows = rows.map(function (r) { return padRow(r, colCount); });



    var parts = [];

    if (intro) parts.push(intro);

    parts.push(rowsToGfmTable(rows, colCount));

    if (tail) parts.push(formatTailSection(tail));

    return parts.join('\n\n');

  }



  function formatTailSection(tail) {

    var s = String(tail || '').trim();

    s = s.replace(/\*\*(关键说明|进一步探索建议|Further exploration[^*]*)\*\*[：:]\s*/gi, '\n\n### $1\n\n');

    s = s.replace(/([。！？.!?)\):])\s+-\s+/g, '$1\n- ');
    s = s.replace(/(?<![a-zA-Z])([。！？.!?)\):])-\s+/g, '$1\n- ');

    return s.trim();

  }



  function repairCompactMarkdown(s) {
    s = String(s || '');

    /* --- 分隔线 + 标题（中/英） */
    s = s.replace(/---+(?=#{1,6}\s)/g, '\n\n---\n\n');
    s = s.replace(/([。！？.!?:：])\s*---+\s*(?=#{1,6}\s|\*\*)/g, '$1\n\n---\n\n');

    s = s.replace(/([^\n#])(#{1,6}\s+\d+\.\s)/g, '$1\n\n$2');
    s = s.replace(/([^\n#])(#{1,6}\s+(?:总结|关键说明|进一步探索|Summary|Further exploration))/gi, '$1\n\n$2');
    s = s.replace(/([。！？.!?)\):）])\s*(#{1,6}\s)/g, '$1\n\n$2');

    /* **小节标题:** 后接正文或列表（英文 AI 最常见粘连） */
    s = s.replace(
      /\*\*([^*\n]{2,160}?)\*\*[：:]\s*-\s+/g,
      '**$1**:\n\n- '
    );
    s = s.replace(
      /\*\*([^*\n]{2,160}?)\*\*[：:]\s*(?=[A-Za-z0-9('"*])/g,
      '**$1**:\n\n'
    );

    s = s.replace(
      /\*\*(进一步探索建议|关键说明|总结|Further exploration[^*]*)\*\*[：:]\s*/gi,
      '\n\n### $1\n\n'
    );
    s = s.replace(/---+\s*(?=###\s*(?:总结|Summary))/gi, '\n\n---\n\n');

    /* 冒号后直接接列表（排除 URL 协议 ://） */
    s = s.replace(/([^/\d\n])[：:]\s*-\s+(?=[A-Za-z*\u4e00-\u9fa5(])/g, '$1:\n\n- ');

    /* 句号/括号后接列表；(?<![a-zA-Z]) 避免 e.g.- / i.e.- 误伤 */
    s = s.replace(/([：:）)])\s*-\s+\*\*/g, '$1\n- **');
    s = s.replace(/([。！？.!?])\s+-\s+\*\*/g, '$1\n- **');
    s = s.replace(/([。！？.!?]\)?)\s+-\s+(?=[A-Za-z*\u4e00-\u9fa5(])/g, '$1\n- ');
    s = s.replace(/(?<![a-zA-Z])([。！？.!?]\)?)-\s+(?=[A-Za-z*\u4e00-\u9fa5(])/g, '$1\n- ');
    s = s.replace(/(\*\*[^*]+?\*\*[。！？.!?])\s*-\s+/g, '$1\n- ');

    /* 有序列表粘连：depend on:1. … / credibility.2. … */
    s = s.replace(/([^/\d\n])[：:]\s*(\d+\.\s+(?:\*\*)?[A-Za-z\u4e00-\u9fa5])/g, '$1:\n\n$2');
    s = s.replace(/(?<![a-zA-Z])([。！？.!?]\)?)\s*(\d+\.\s+(?:\*\*)?[A-Za-z\u4e00-\u9fa5])/g, '$1\n\n$2');

    /* 段落后接 **Bold 小节** 或 First, 引导句 */
    s = s.replace(/([。！？.!?]\)?)\s+(?=\*\*[^*]+?\*\*[：:])/g, '$1\n\n');
    s = s.replace(/(?<![a-zA-Z])([.!?])\s+(First,\s)/g, '$1\n\n$2');

    return s;
  }



  function repairCompactPipeTables(s) {

    s = String(s || '');

    s = s.replace(/([。！？])\s*(\|\s*对比维度\s*\|)/g, '$1\n\n$2');

    s = s.replace(/([。！？])\s*(\|[^|\n]+\|[^|\n]+\|\s*\|\|)/g, '$1\n\n$2');



    var lines = s.split('\n');

    var out = [];

    lines.forEach(function (line) {

      if (line.indexOf('||') >= 0 && line.indexOf('|') >= 0) {

        out.push(expandCompactPipeLine(line));

      } else {

        out.push(line);

      }

    });

    return out.join('\n');

  }



  function findHeaderIndex(cells) {

    for (var i = 0; i < Math.min(cells.length, 3); i++) {

      if (isHeaderLabel(cells[i])) return i;

    }

    return -1;

  }



  function parseTabTableBlock(blockLines, colCount) {

    var intro = '';

    var rows = [];

    var n = colCount || DEFAULT_COLS;



    blockLines.forEach(function (line) {

      var trimmed = line.trim();

      if (!trimmed || isPipeGarbage(trimmed)) return;



      var parts = trimmed.split(/\t{2,}/);

      parts.forEach(function (part) {

        var cells = splitTabFields(part);

        if (!cells.length) return;



        if (!rows.length) {

          var hIdx = findHeaderIndex(cells);

          if (hIdx === 1 && cells.length >= n + 1) {

            intro = cells[0];

            rows.push(cells.slice(1, 1 + n));

            cells = cells.slice(1 + n);

          } else if (hIdx === 0 && cells.length >= n) {

            rows.push(cells.slice(0, n));

            cells = cells.slice(n);

          } else if (cells.length === n && isHeaderLabel(cells[0])) {

            rows.push(cells.slice(0, n));

            cells = [];

          } else if (cells.length > n && cells[0].length > 12 && hIdx === -1) {

            intro = cells[0];

            cells = cells.slice(1);

          }

        }



        for (var j = 0; j < cells.length; j += n) {

          var row = cells.slice(j, j + n);

          if (row.length >= 2) rows.push(padRow(row, n));

        }

      });

    });



    if (!rows.length) return null;

    return {

      intro: intro,

      markdown: rowsToGfmTable(rows, n)

    };

  }



  function lineHasTabHeader(line) {

    if (line.indexOf('\t') === -1) return false;

    if (/对比维度|测试场景/.test(line)) return true;

    var first = splitTabFields(String(line).split(/\t{2,}/)[0]);

    return findHeaderIndex(first) >= 0;

  }



  function lineIsTabData(line) {

    var t = String(line || '').trim();

    if (!t || isPipeGarbage(t)) return false;

    if (t.indexOf('\t') === -1) return false;

    if (/^#{1,6}\s/.test(t)) return false;

    return splitTabFields(t.split(/\t{2,}/)[0]).length >= 2;

  }



  function repairMultiLineTabTables(s) {

    var lines = s.split('\n');

    var out = [];

    var i = 0;



    while (i < lines.length) {

      var line = lines[i];

      var trimmed = line.trim();



      if (isPipeGarbage(trimmed)) {

        i++;

        continue;

      }



      if (lineHasTabHeader(line)) {

        var block = [line];

        i++;

        while (i < lines.length) {

          var t = lines[i].trim();

          if (!t || isPipeGarbage(t)) {

            block.push(lines[i]);

            i++;

            continue;

          }

          if (lineIsTabData(lines[i])) {

            block.push(lines[i]);

            i++;

            continue;

          }

          break;

        }



        var parsed = parseTabTableBlock(block, DEFAULT_COLS);

        if (parsed) {

          out.push(parsed.intro ? parsed.intro + '\n\n' + parsed.markdown : parsed.markdown);

          continue;

        }

      }



      if (trimmed.indexOf('\t') >= 0) {

        var single = parseTabTableBlock([line], DEFAULT_COLS);

        if (single) {

          out.push(single.intro ? single.intro + '\n\n' + single.markdown : single.markdown);

          i++;

          continue;

        }

      }



      out.push(line);

      i++;

    }



    return out.join('\n');

  }



  function repairPipeTables(s) {

    var lines = s.split('\n');

    var out = [];

    var i = 0;



    while (i < lines.length) {

      var trimmed = lines[i].trim();

      if (isPipeGarbage(trimmed)) { i++; continue; }



      if (trimmed.indexOf('\t') >= 0 && trimmed.indexOf('|') === -1) {

        var headerCells = splitTabFields(trimmed);

        if (headerCells.length >= 2 && headerCells.length <= 8 && isHeaderLabel(headerCells[0])) {

          var blockRows = [headerCells];

          i++;

          var pendingTitle = null;



          while (i < lines.length) {

            var t = lines[i].trim();

            if (!t || isPipeGarbage(t)) { i++; continue; }

            if (/^#{1,6}\s|^关键解释|^进一步探索|^---/.test(t)) break;

            if (t.indexOf('|') === -1 && t.indexOf('\t') === -1) break;



            if (/^\|+\s*[^|]+\s*$/.test(t) && t.replace(/\|/g, '').trim().length > 0) {

              pendingTitle = t.replace(/^\|+\s*/, '').trim();

              i++;

              continue;

            }



            if (t.indexOf('|') !== -1) {

              var segments = t.split(/\s*\|\|\s*/);

              for (var si = 0; si < segments.length; si++) {

                var seg = segments[si].trim();

                if (!seg) continue;

                var inner = seg.replace(/^\|+\s*/, '').replace(/\s*\|+\s*$/, '');

                if (inner.indexOf('|') === -1) {

                  pendingTitle = inner;

                  continue;

                }

                var cells = inner.split('|').map(function (c) { return c.trim(); });

                if (cells.length < 2) continue;

                var row = pendingTitle ? [pendingTitle].concat(cells) : cells;

                pendingTitle = null;

                blockRows.push(padRow(row, headerCells.length));

              }

              i++;

              continue;

            }

            break;

          }



          if (blockRows.length > 1) {

            out.push(rowsToGfmTable(blockRows, headerCells.length));

            continue;

          }

        }

      }



      out.push(lines[i]);

      i++;

    }

    return out.join('\n');

  }



  function normalizeMarkdown(src) {

    var s = String(src || '');

    s = s.replace(/\\n/g, '\n').replace(/\r\n/g, '\n').replace(/\u00a0/g, ' ');



    s = s.split('\n').filter(function (line) {

      var t = line.trim();

      return !isPipeGarbage(t);

    }).join('\n');



    s = repairCompactMarkdown(s);

    s = repairCompactPipeTables(s);

    s = repairMultiLineTabTables(s);

    s = repairPipeTables(s);



    s = s.replace(/^\s*#{1,6}\s*$/gm, '');

    s = s.replace(/^\s*\|+\s*:?\s*$/gm, '');



    s = s.replace(/^([\u4e00-\u9fa5A-Za-z0-9（()·\-\s]{2,14})[：:]\s*(.{4,})$/gm, function (full, title, body) {

      if (/^\|/.test(body.trim()) || title.indexOf('，') !== -1) return full;

      if (body.indexOf('|') !== -1 && body.indexOf('||') !== -1) return full;

      return '### ' + title.trim() + '\n\n' + body.trim();

    });



    s = s.replace(/\n{3,}/g, '\n\n');

    return s.trim();

  }



  function extractMath(src) {

    var blocks = [];

    var n = 0;

    function stash(tex, display) {

      var id = '\uE000M' + (n++) + '\uE001';

      blocks.push({ id: id, tex: tex, display: display });

      return id;

    }

    var out = src;

    out = out.replace(/\$\$([\s\S]+?)\$\$/g, function (_, t) { return stash(t.trim(), true); });

    out = out.replace(/\\\[([\s\S]+?)\\\]/g, function (_, t) { return stash(t.trim(), true); });

    out = out.replace(/\\\(([\s\S]+?)\\\)/g, function (_, t) { return stash(t.trim(), false); });

    out = out.replace(/(^|[^$\\])\$(?!\$)((?:\\.|[^$\n])+?)\$(?!\$)/g, function (_, pre, t) {

      return pre + stash(t.trim(), false);

    });

    return { text: out, blocks: blocks };

  }



  function renderTex(blocks, html) {

    var out = html;

    blocks.forEach(function (b) {

      var rendered;

      if (global.katex && global.katex.renderToString) {

        try {

          rendered = global.katex.renderToString(b.tex, {

            displayMode: b.display,

            throwOnError: false,

            strict: 'ignore',

            trust: false

          });

        } catch (e) {

          rendered = '<code class="sgt-md-math-fail">' + escapeHtml(b.tex) + '</code>';

        }

      } else {

        rendered = '<code class="sgt-md-math-fail">' + escapeHtml(b.tex) + '</code>';

      }

      var wrap = b.display

        ? '<div class="sgt-md-math-block">' + rendered + '</div>'

        : '<span class="sgt-md-math-inline">' + rendered + '</span>';

      out = out.split(b.id).join(wrap);

    });

    return out;

  }



  function wrapHtmlTables(html) {

    return String(html || '').replace(/<table(\s|>)/g, '<div class="sgt-md-table-wrap"><table$1')

      .replace(/<\/table>/g, '</table></div>');

  }



  function fallbackHtml(src) {

    return src.split(/\n\n+/).map(function (blk) {

      var t = blk.trim();

      if (!t) return '';

      if (t.indexOf('|') !== -1 && t.indexOf('---') !== -1) {

        return '<pre class="sgt-md-pre">' + escapeHtml(t) + '</pre>';

      }

      return '<p>' + escapeHtml(t).replace(/\n/g, '<br>') + '</p>';

    }).join('');

  }



  function renderMarkdown(src) {

    if (!src) return '';

    try {

      var normalized = normalizeMarkdown(src);

      var extracted = extractMath(normalized);

      var html;



      if (global.marked && typeof global.marked.parse === 'function') {

        html = wrapHtmlTables(global.marked.parse(extracted.text));

      } else {

        html = fallbackHtml(extracted.text);

      }



      return renderTex(extracted.blocks, html);

    } catch (err) {

      if (global.console && global.console.error) {

        global.console.error('[SgtTutorMd]', err);

      }

      return fallbackHtml(String(src || ''));

    }

  }



  global.SgtTutorMd = {

    render: renderMarkdown,

    normalize: normalizeMarkdown,

    escapeHtml: escapeHtml

  };

})(typeof window !== 'undefined' ? window : this);


