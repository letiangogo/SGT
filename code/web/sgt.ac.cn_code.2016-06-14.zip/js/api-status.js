/**
 * Footer Solver API health pill (main site pages).
 */
(function () {
  'use strict';
  var pills = document.querySelectorAll('[data-api-pill]');
  if (!pills.length) return;

  var TIMEOUT = 6000;

  function setState(ok, version) {
    pills.forEach(function (el) {
      var isZh = el.classList.contains('lang-zh');
      el.classList.remove('api-pill-pending', 'api-pill-ok', 'api-pill-off');
      if (ok) {
        el.classList.add('api-pill-ok');
        el.textContent = isZh
          ? 'Solver API：在线' + (version ? ' v' + version : '')
          : 'Solver API: online' + (version ? ' v' + version : '');
      } else {
        el.classList.add('api-pill-off');
        el.textContent = isZh ? 'Solver API：暂不可用' : 'Solver API: unavailable';
      }
    });
  }

  var ctrl = new AbortController();
  var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT);
  fetch('/api/health', { signal: ctrl.signal })
    .then(function (res) {
      clearTimeout(timer);
      if (!res.ok) throw new Error('http');
      return res.json();
    })
    .then(function (data) {
      setState(data && data.status === 'ok', data && data.version);
    })
    .catch(function () {
      clearTimeout(timer);
      setState(false);
    });
})();
