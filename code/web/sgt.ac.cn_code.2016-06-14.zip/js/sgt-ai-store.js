/**
 * SGT AI 精灵 — 本地存储（当前对话 + 临时归档）
 * 仅存 localStorage，不上传云端
 */
(function (global) {
  'use strict';

  var CURRENT_KEY = 'sgt_ai_genie_v1';
  var ARCHIVES_KEY = 'sgt_ai_genie_archives_v1';
  var MAX_ARCHIVES = 50;
  var MAX_MSG = 12;

  function deriveTitle(messages) {
    var i;
    for (i = 0; i < messages.length; i++) {
      if (messages[i].role === 'user' && messages[i].content) {
        var t = String(messages[i].content).trim().replace(/\s+/g, ' ');
        if (t.length > 40) return t.slice(0, 40) + '…';
        return t || (global.document && global.document.documentElement.classList.contains('lang-en')
          ? 'Untitled chat' : '未命名对话');
      }
    }
    return global.document && global.document.documentElement.classList.contains('lang-en')
      ? 'Untitled chat' : '未命名对话';
  }

  function getCurrent() {
    try {
      var raw = global.localStorage.getItem(CURRENT_KEY);
      if (!raw) return { messages: [], isOpen: false, ts: Date.now() };
      var data = JSON.parse(raw);
      return {
        messages: Array.isArray(data.messages) ? data.messages : [],
        isOpen: !!data.isOpen,
        ts: data.ts || Date.now()
      };
    } catch (e) {
      return { messages: [], isOpen: false, ts: Date.now() };
    }
  }

  function saveCurrent(state) {
    try {
      global.localStorage.setItem(CURRENT_KEY, JSON.stringify({
        v: 1,
        messages: (state.messages || []).slice(-MAX_MSG),
        isOpen: !!state.isOpen,
        ts: Date.now()
      }));
    } catch (e) { /* quota / private mode */ }
  }

  function listArchives() {
    try {
      var raw = global.localStorage.getItem(ARCHIVES_KEY);
      if (!raw) return [];
      var data = JSON.parse(raw);
      return Array.isArray(data.items) ? data.items : [];
    } catch (e) {
      return [];
    }
  }

  function saveArchives(items) {
    try {
      global.localStorage.setItem(ARCHIVES_KEY, JSON.stringify({
        v: 1,
        items: items.slice(0, MAX_ARCHIVES)
      }));
    } catch (e) { /* ignore */ }
  }

  function archiveMessages(messages, meta) {
    if (!messages || !messages.length) return null;
    var item = {
      id: 'arch_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      title: deriveTitle(messages),
      messages: messages.slice(),
      messageCount: messages.length,
      archivedAt: Date.now(),
      startedAt: meta && meta.startedAt ? meta.startedAt : null
    };
    var items = listArchives();
    items.unshift(item);
    saveArchives(items);
    return item;
  }

  function getArchive(id) {
    var items = listArchives();
    for (var i = 0; i < items.length; i++) {
      if (items[i].id === id) return items[i];
    }
    return null;
  }

  function deleteArchive(id) {
    saveArchives(listArchives().filter(function (a) { return a.id !== id; }));
  }

  function archiveAndClearCurrent(keepOpen) {
    var cur = getCurrent();
    var archived = null;
    if (cur.messages.length) {
      archived = archiveMessages(cur.messages, { startedAt: cur.ts });
    }
    saveCurrent({ messages: [], isOpen: keepOpen != null ? keepOpen : cur.isOpen });
    return archived;
  }

  global.SgtAiStore = {
    getCurrent: getCurrent,
    saveCurrent: saveCurrent,
    listArchives: listArchives,
    getArchive: getArchive,
    deleteArchive: deleteArchive,
    archiveMessages: archiveMessages,
    archiveAndClearCurrent: archiveAndClearCurrent,
    deriveTitle: deriveTitle
  };
})(typeof window !== 'undefined' ? window : this);
