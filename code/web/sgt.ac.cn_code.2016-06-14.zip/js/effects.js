/**
 * SGT 引力物理科技感动效
 * Canvas 引力场粒子 · 滚动显现 · 导航玻璃态 · 公式高亮
 */
(function () {
  'use strict';

  var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isMobile = window.innerWidth < 900;

  /* ========== 注入 Canvas 背景 ========== */
  function initCanvas() {
    if (prefersReduced || document.getElementById('gravity-canvas')) return;

    var canvas = document.createElement('canvas');
    canvas.id = 'gravity-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    document.body.prepend(canvas);

    var ctx = canvas.getContext('2d');
    var particles = [];
    var mouse = { x: -9999, y: -9999 };
    var w, h, cx, cy;
    var running = true;

    function resize() {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      cx = w * 0.5;
      cy = h * 0.28;
    }

    function createParticles() {
      particles = [];
      var count = isMobile ? 40 : 90;
      for (var i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          r: Math.random() * 1.2 + 0.4,
          alpha: Math.random() * 0.35 + 0.08
        });
      }
    }

    function drawGrid() {
      ctx.strokeStyle = 'rgba(0, 71, 146, 0.04)';
      ctx.lineWidth = 1;
      var step = 60;
      for (var x = 0; x < w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (var y = 0; y < h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    }

    function drawAttractor() {
      var grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 120);
      grd.addColorStop(0, 'rgba(0, 71, 146, 0.06)');
      grd.addColorStop(0.5, 'rgba(0, 71, 146, 0.02)');
      grd.addColorStop(1, 'rgba(0, 71, 146, 0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(cx, cy, 120, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(0, 71, 146, 0.12)';
      ctx.lineWidth = 1;
      for (var ring = 1; ring <= 3; ring++) {
        ctx.beginPath();
        ctx.arc(cx, cy, ring * 40, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    function updateParticle(p) {
      var ax = cx - p.x;
      var ay = cy - p.y;
      var dist = Math.sqrt(ax * ax + ay * ay) + 80;
      var force = 800 / (dist * dist);
      p.vx += (ax / dist) * force * 0.016;
      p.vy += (ay / dist) * force * 0.016;

      if (mouse.x > 0) {
        var mx = mouse.x - p.x;
        var my = mouse.y - p.y;
        var md = Math.sqrt(mx * mx + my * my) + 60;
        var mf = 400 / (md * md);
        p.vx += (mx / md) * mf * 0.012;
        p.vy += (my / md) * mf * 0.012;
      }

      p.vx *= 0.992;
      p.vy *= 0.992;
      p.x += p.vx;
      p.y += p.vy;

      if (p.x < 0) p.x = w;
      if (p.x > w) p.x = 0;
      if (p.y < 0) p.y = h;
      if (p.y > h) p.y = 0;
    }

    function drawParticle(p) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 71, 146, ' + p.alpha + ')';
      ctx.fill();
    }

    function connectNearby() {
      for (var i = 0; i < particles.length; i++) {
        for (var j = i + 1; j < particles.length; j++) {
          var dx = particles[i].x - particles[j].x;
          var dy = particles[i].y - particles[j].y;
          var d = Math.sqrt(dx * dx + dy * dy);
          if (d < 100) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = 'rgba(0, 71, 146, ' + (0.06 * (1 - d / 100)) + ')';
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
    }

    function frame() {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      drawGrid();
      drawAttractor();
      particles.forEach(function (p) {
        updateParticle(p);
        drawParticle(p);
      });
      connectNearby();
      requestAnimationFrame(frame);
    }

    resize();
    createParticles();
    frame();

    window.addEventListener('resize', function () {
      isMobile = window.innerWidth < 900;
      resize();
      createParticles();
    });

    document.addEventListener('mousemove', function (e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    document.addEventListener('mouseleave', function () {
      mouse.x = -9999;
      mouse.y = -9999;
    });

    document.addEventListener('visibilitychange', function () {
      running = !document.hidden;
      if (running) frame();
    });
  }

  /* ========== 滚动显现 ========== */
  function initReveal() {
    var selector =
      '.section, .doc-meta, .hero, .formula-block, .table-wrap, .info-box, .liability-block, .declaration-box, .page-title, .metrics-strip, .compare-visual, .cosmo-timeline, .nav-card, .quote-box, .author-line, .advantage-card, .roadmap-step, .roadmap-header, .roadmap-domain, .roadmap-domains, .vision-panel, .roadmap-epigraph, .zkav-spotlight, .zkav-initiative, .lab-hero, .lab-section, .lab-disclaimer';
    var seen = typeof Set !== 'undefined' ? new Set() : null;
    var targets = [];

    function addTarget(el) {
      if (!el) return;
      if (seen) {
        if (seen.has(el)) return;
        seen.add(el);
      } else if (targets.indexOf(el) !== -1) {
        return;
      }
      targets.push(el);
    }

    document.querySelectorAll(selector).forEach(addTarget);
    document.querySelectorAll('.reveal').forEach(addTarget);

    targets.forEach(function (el, i) {
      el.classList.add('reveal');
      el.style.transitionDelay = (i % 6) * 0.06 + 's';
    });

    if (prefersReduced) {
      targets.forEach(function (el) { el.classList.add('revealed'); });
      return;
    }

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

    function revealIfInView(el) {
      var rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.95 && rect.bottom > 0) {
        el.classList.add('revealed');
        observer.unobserve(el);
        return true;
      }
      return false;
    }

    targets.forEach(function (el) {
      if (!revealIfInView(el)) observer.observe(el);
    });

    window.addEventListener('load', function () {
      targets.forEach(function (el) {
        if (!el.classList.contains('revealed')) revealIfInView(el);
      });
    }, { once: true });
  }

  /* ========== 导航滚动态 ========== */
  function initHeaderScroll() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    function onScroll() {
      header.classList.toggle('scrolled', window.scrollY > 20);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ========== 表格行交互 ========== */
  function initTableHover() {
    document.querySelectorAll('.academic-table tbody tr:not(.cat-row)').forEach(function (row) {
      row.addEventListener('mouseenter', function () {
        row.style.transform = 'translateX(2px)';
      });
      row.addEventListener('mouseleave', function () {
        row.style.transform = '';
      });
    });
  }

  /* ========== 公式块扫描线 ========== */
  function initFormulaScan() {
    document.querySelectorAll('.formula-block').forEach(function (block) {
      if (!block.querySelector('.formula-scan')) {
        var scan = document.createElement('div');
        scan.className = 'formula-scan';
        block.appendChild(scan);
      }
    });
  }

  /* ========== 导航当前页指示器 ========== */
  function initNavIndicator() {
    var nav = document.getElementById('site-nav');
    if (!nav) return;
    var active = nav.querySelector('a.active');
    if (!active) return;

    var indicator = document.createElement('span');
    indicator.className = 'nav-indicator';
    nav.style.position = 'relative';
    active.parentElement.appendChild(indicator);
  }

  /* ========== 对比条入场动画 ========== */
  function initCompareBars() {
    var rows = document.querySelectorAll('.compare-bar');
    if (!rows.length || prefersReduced) return;

    rows.forEach(function (bar) {
      var target = bar.style.width;
      if (!target) {
        var m = (bar.getAttribute('style') || '').match(/width:\s*([^;]+)/i);
        target = m ? m[1].trim() : '100%';
      }
      bar.dataset.targetWidth = target;
      bar.style.width = '0';
    });

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var bar = entry.target;
          bar.style.width = bar.dataset.targetWidth || bar.style.width;
          observer.unobserve(bar);
        }
      });
    }, { threshold: 0.3 });

    rows.forEach(function (bar) { observer.observe(bar); });
  }

  var effectsBooted = false;

  function bootEffects() {
    if (effectsBooted) return;
    effectsBooted = true;
    initCanvas();
    initReveal();
    initHeaderScroll();
    initTableHover();
    initFormulaScan();
    initNavIndicator();
    initCompareBars();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootEffects);
  } else {
    bootEffects();
  }
})();
