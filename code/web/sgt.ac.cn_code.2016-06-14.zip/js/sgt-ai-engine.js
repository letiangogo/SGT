/**
 * SGT AI 精灵 — 共享对话引擎（浮窗 / 专题页）
 */
(function (global) {
  'use strict';

  function createChat(config) {
    var API_URL = config.apiUrl || '/chat';
    var TIMEOUT_MS = config.timeoutMs || 60000;
    var MAX_ROUNDS = config.maxRounds || 6;
    var MAX_INPUT_CHARS = config.maxInputChars || 500;
    var STREAM_RENDER_MS = 120;
    var readOnly = !!config.readOnly;

    var messages = (config.initialMessages || []).slice();
    var isLoading = false;
    var welcomed = false;

    function $(sel) {
      return typeof sel === 'string' ? document.querySelector(sel) : sel;
    }

    var messagesEl = $(config.messagesEl);
    var inputEl = config.inputEl ? $(config.inputEl) : null;
    var sendEl = config.sendBtnEl ? $(config.sendBtnEl) : null;
    var errEl = config.errorEl ? $(config.errorEl) : null;

    function isEn() {
      return document.documentElement.classList.contains('lang-en');
    }

    function t(zh, en) { return isEn() ? en : zh; }

    function md() { return global.SgtTutorMd; }

    function persist() {
      if (config.onPersist) config.onPersist(messages.slice());
    }

    function buildContext(msgs, currentQuery) {
      var recent = msgs.slice(-12);
      var context = recent.map(function (m) {
        var role = m.role === 'user'
          ? (isEn() ? 'User' : '用户')
          : (isEn() ? 'Genie' : 'AI精灵');
        var text = m.content.length > 100 ? m.content.slice(0, 100) + '...' : m.content;
        return role + '：' + text;
      }).join('；');
      var pre = isEn() ? '[Context] ' : '[前情] ';
      var preEnd = isEn() ? ' [/Context] ' : ' [/前情] ';
      var cur = isEn() ? '[Question] ' : '[当前问题] ';
      if (!context) return cur + currentQuery;
      return pre + context + preEnd + cur + currentQuery;
    }

    function scrollToBottom() {
      if (!messagesEl) return;
      ensureScrollAnchor();
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function ensureScrollAnchor() {
      if (!messagesEl) return null;
      var anchor = messagesEl.querySelector('.sgt-ai-scroll-anchor');
      if (!anchor) {
        anchor = document.createElement('div');
        anchor.className = 'sgt-ai-scroll-anchor';
        anchor.setAttribute('aria-hidden', 'true');
        messagesEl.appendChild(anchor);
      } else if (anchor.nextSibling) {
        messagesEl.appendChild(anchor);
      }
      return anchor;
    }

    function appendToMessages(node) {
      if (!messagesEl || !node) return;
      messagesEl.insertBefore(node, ensureScrollAnchor());
    }

    function showWelcome() {
      if (welcomed || !messagesEl || readOnly) return;
      if (config.welcomeHtml) {
        ensureScrollAnchor().insertAdjacentHTML('beforebegin', config.welcomeHtml);
      } else {
        var el = document.createElement('div');
        el.className = 'sgt-tutor-welcome';
        el.innerHTML = '<span class="lang-zh">我是 SGT AI 精灵，关于空能引力理论的问题，可以直接问我。因算力资源有限，每段对话最多 <strong>6 轮</strong>，单次输入不超过 <strong>500 字</strong>，请尽量简明。</span>' +
          '<span class="lang-en">I am SGT AI Genie — ask me about Spatial Pressure Gravitational Theory. Due to limited resources: max <strong>6 turns</strong> per chat, <strong>500 characters</strong> per message — please be concise.</span>';
        messagesEl.insertBefore(el, ensureScrollAnchor());
      }
      welcomed = true;
      scrollToBottom();
    }

    function clearWelcome() {
      if (!messagesEl) return;
      var w = messagesEl.querySelector('.sgt-tutor-welcome');
      if (w) w.remove();
      welcomed = true;
    }

    function appendUserBubble(text) {
      clearWelcome();
      var wrap = document.createElement('div');
      wrap.className = 'sgt-tutor-msg user';
      wrap.innerHTML = '<div class="sgt-tutor-bubble"></div>';
      wrap.querySelector('.sgt-tutor-bubble').textContent = text;
      appendToMessages(wrap);
      scrollToBottom();
    }

    function createAssistantBubble() {
      clearWelcome();
      var wrap = document.createElement('div');
      wrap.className = 'sgt-tutor-msg assistant';
      var bubble = document.createElement('div');
      bubble.className = 'sgt-tutor-bubble sgt-md-body';
      var actions = document.createElement('div');
      actions.className = 'sgt-tutor-msg-actions';
      var copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'sgt-tutor-copy-raw';
      copyBtn.hidden = true;
      copyBtn.setAttribute('aria-label', t('复制原文', 'Copy raw reply'));
      copyBtn.innerHTML = '<span class="lang-zh">复制原文</span><span class="lang-en">Copy raw</span>';
      actions.appendChild(copyBtn);
      var sources = document.createElement('div');
      sources.className = 'sgt-tutor-sources';
      sources.style.display = 'none';
      wrap.appendChild(bubble);
      wrap.appendChild(actions);
      wrap.appendChild(sources);
      appendToMessages(wrap);
      scrollToBottom();
      return { wrap: wrap, bubble: bubble, copyBtn: copyBtn, sources: sources, streamTimer: null, rawText: '' };
    }

    function buildRawExport(text, sources) {
      var body = String(text || '');
      if (!sources || !sources.length) return body;
      var srcLine = sources.join(' · ');
      return body + '\n\n---\n' + t('参考来源', 'Sources') + ':\n' + srcLine;
    }

    function copyTextToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }
      return new Promise(function (resolve, reject) {
        try {
          var ta = document.createElement('textarea');
          ta.value = text;
          ta.setAttribute('readonly', '');
          ta.style.position = 'fixed';
          ta.style.left = '-9999px';
          document.body.appendChild(ta);
          ta.select();
          var ok = document.execCommand('copy');
          document.body.removeChild(ta);
          if (ok) resolve();
          else reject(new Error('copy failed'));
        } catch (e) {
          reject(e);
        }
      });
    }

    function flashCopyBtn(btn) {
      if (!btn) return;
      btn.classList.add('is-copied');
      btn.innerHTML = '<span class="lang-zh">已复制</span><span class="lang-en">Copied</span>';
      setTimeout(function () {
        btn.classList.remove('is-copied');
        btn.innerHTML = '<span class="lang-zh">复制原文</span><span class="lang-en">Copy raw</span>';
      }, 1600);
    }

    function bindCopyRaw(ui, sources) {
      if (!ui || !ui.copyBtn) return;
      ui.copyBtn.onclick = function () {
        var payload = buildRawExport(ui.rawText, sources);
        if (!payload) return;
        copyTextToClipboard(payload).then(function () {
          flashCopyBtn(ui.copyBtn);
        }).catch(function () {
          showError(t('复制失败，请手动选择文本', 'Copy failed — please select text manually'));
        });
      };
    }

    function showTyping() {
      if (!messagesEl) return;
      var el = document.createElement('div');
      el.className = 'sgt-tutor-typing';
      el.id = 'sgt-tutor-typing';
      el.innerHTML = '<span></span><span></span><span></span>';
      appendToMessages(el);
      scrollToBottom();
    }

    function hideTyping() {
      var el = document.getElementById('sgt-tutor-typing');
      if (el) el.remove();
    }

    function setSources(el, list) {
      if (!list || !list.length) {
        el.style.display = 'none';
        return;
      }
      var label = t('参考：', 'Sources: ');
      var esc = md() ? md().escapeHtml : function (s) { return s; };
      el.innerHTML = label + list.map(function (s) {
        if (/^https?:\/\//i.test(s)) {
          return '<a href="' + esc(s) + '" target="_blank" rel="noopener">' + esc(s) + '</a>';
        }
        return esc(s);
      }).join(' · ');
      el.style.display = 'block';
    }

    function renderBubbleMarkdown(bubble, text, streaming) {
      if (!streaming) bubble.classList.remove('streaming');
      var renderer = md();
      if (renderer && renderer.render) {
        bubble.innerHTML = renderer.render(text);
        bubble.classList.add('sgt-md-rendered');
        if (streaming) bubble.classList.add('streaming');
      } else {
        bubble.textContent = text;
        bubble.classList.remove('sgt-md-rendered');
      }
      scrollToBottom();
    }

    function scheduleStreamRender(ui, text) {
      if (ui.streamTimer) clearTimeout(ui.streamTimer);
      ui.streamTimer = setTimeout(function () {
        renderBubbleMarkdown(ui.bubble, text, true);
      }, STREAM_RENDER_MS);
    }

    function finishReply(ui, text, sources) {
      if (ui.streamTimer) {
        clearTimeout(ui.streamTimer);
        ui.streamTimer = null;
      }
      ui.rawText = String(text || '');
      renderBubbleMarkdown(ui.bubble, ui.rawText, false);
      setSources(ui.sources, sources);
      if (ui.copyBtn) {
        ui.copyBtn.hidden = !ui.rawText;
        bindCopyRaw(ui, sources);
      }
      scrollToBottom();
    }

    function setLoading(on) {
      isLoading = on;
      if (inputEl) inputEl.disabled = on || readOnly;
      if (sendEl) sendEl.disabled = on || readOnly;
    }

    function showError(msg) {
      if (!errEl) return;
      errEl.textContent = msg;
      errEl.classList.add('visible');
    }

    function hideError() {
      if (!errEl) return;
      errEl.classList.remove('visible');
    }

    function extractFromPayload(payload, cb) {
      if (!payload || payload === '[DONE]') return;
      var piece = '';
      var replace = false;
      var sources = null;
      try {
        var j = JSON.parse(payload);
        if (j.sources) sources = j.sources;
        if (j.reply != null) { piece = String(j.reply); replace = true; }
        else if (j.delta != null) piece = String(j.delta);
        else if (j.content != null) piece = String(j.content);
        else if (j.text != null) piece = String(j.text);
        else if (j.token != null) piece = String(j.token);
        else if (j.message != null && typeof j.message === 'string') piece = j.message;
        else if (j.choices && j.choices[0]) {
          var c0 = j.choices[0];
          if (c0.delta && c0.delta.content != null) piece = String(c0.delta.content);
          else if (c0.message && c0.message.content != null) {
            piece = String(c0.message.content);
            replace = true;
          } else if (c0.text != null) piece = String(c0.text);
        } else if (j.data != null && typeof j.data === 'string') piece = j.data;
      } catch (e) {
        piece = payload;
      }
      if (piece || sources) cb(piece, replace, sources);
    }

    function shouldUseStreamReader(res) {
      var ct = (res.headers.get('content-type') || '').toLowerCase();
      if (ct.indexOf('text/event-stream') !== -1) return true;
      if (ct.indexOf('application/x-ndjson') !== -1) return true;
      if (ct.indexOf('application/stream+json') !== -1) return true;
      if (res.headers.get('x-vercel-ai-data-stream')) return true;
      if (res.headers.get('x-accel-buffering') === 'no') return true;
      if (!res.headers.get('content-length') && res.body) return true;
      return false;
    }

    function processStreamLines(buffer, onLine, final) {
      var lines = buffer.split('\n');
      var rest = final ? '' : (lines.pop() || '');
      lines.forEach(function (raw) {
        var line = raw.trim();
        if (!line) return;
        if (line.indexOf('data:') === 0) line = line.slice(5).trim();
        if (line.indexOf('event:') === 0) return;
        onLine(line);
      });
      return rest;
    }

    function readStreamBody(res, ui) {
      return new Promise(function (resolve, reject) {
        if (!res.body || !res.body.getReader) {
          reject(new Error(t('流式响应不可用', 'Streaming not supported')));
          return;
        }
        var reader = res.body.getReader();
        var decoder = new TextDecoder();
        var buffer = '';
        var full = '';
        var sources = [];
        hideTyping();
        ui.bubble.classList.add('streaming');
        if (ui.copyBtn) ui.copyBtn.hidden = true;

        function applyPiece(piece, replace, src) {
          if (src) sources = src;
          if (!piece) return;
          if (replace) full = piece;
          else full += piece;
          scheduleStreamRender(ui, full);
        }

        function pump() {
          reader.read().then(function (result) {
            if (result.done) {
              buffer = processStreamLines(buffer, function (line) {
                extractFromPayload(line, applyPiece);
              }, true);
              if (buffer.trim()) extractFromPayload(buffer.trim(), applyPiece);
              finishReply(ui, full, sources);
              resolve({ reply: full, sources: sources });
              return;
            }
            buffer += decoder.decode(result.value, { stream: true });
            buffer = processStreamLines(buffer, function (line) {
              extractFromPayload(line, applyPiece);
            }, false);
            pump();
          }).catch(reject);
        }
        pump();
      });
    }

    function parseAggregatedText(text) {
      var trimmed = (text || '').trim();
      if (!trimmed) return { reply: '', sources: [] };
      try {
        var data = JSON.parse(trimmed);
        if (data && (data.reply != null || data.content != null)) {
          return {
            reply: String(data.reply != null ? data.reply : data.content),
            sources: data.sources || []
          };
        }
      } catch (e) { /* ignore */ }
      var full = '';
      var sources = [];
      var sawStream = false;
      processStreamLines(trimmed, function (line) {
        extractFromPayload(line, function (piece, replace, src) {
          sawStream = true;
          if (src) sources = src;
          if (replace) full = piece;
          else full += piece;
        });
      }, true);
      if (sawStream && full) return { reply: full, sources: sources };
      return { reply: trimmed, sources: [] };
    }

    function postChat(apiMessage) {
      var ctrl = new AbortController();
      var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
      return fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'text/event-stream, application/json, application/x-ndjson'
        },
        body: JSON.stringify({ message: apiMessage }),
        signal: ctrl.signal
      }).then(function (res) {
        clearTimeout(timer);
        if (!res.ok) {
          return res.json().catch(function () { return {}; }).then(function (data) {
            var msg = data.error || data.detail || data.message || ('HTTP ' + res.status);
            throw new Error(typeof msg === 'string' ? msg : t('请求失败', 'Request failed'));
          });
        }
        return res;
      }).catch(function (err) {
        clearTimeout(timer);
        if (err.name === 'AbortError') {
          throw new Error(t('请求超时（60 秒），请稍后重试', 'Request timed out (60s) — please retry'));
        }
        if (err.message && err.message.indexOf('Failed to fetch') !== -1) {
          throw new Error(t('网络连接失败', 'Network error'));
        }
        throw err;
      });
    }

    function renderAll() {
      if (!messagesEl) return;
      messagesEl.innerHTML = '';
      welcomed = true;
      if (!messages.length) {
        welcomed = false;
        if (!readOnly) showWelcome();
        return;
      }
      messages.forEach(function (m) {
        if (m.role === 'user') appendUserBubble(m.content);
        else if (m.role === 'assistant') {
          var ui = createAssistantBubble();
          finishReply(ui, m.content || '', m.sources || []);
        }
      });
      ensureScrollAnchor();
    }

    function updateCharCount() {
      if (!inputEl) return;
      var counter = config.charCountEl ? $(config.charCountEl) : null;
      if (!counter) return;
      var n = (inputEl.value || '').length;
      counter.textContent = n + '/' + MAX_INPUT_CHARS;
      counter.classList.toggle('is-near-limit', n > MAX_INPUT_CHARS * 0.9);
      counter.classList.toggle('is-at-limit', n >= MAX_INPUT_CHARS);
    }

    function sendMessage() {
      if (isLoading || readOnly || !inputEl) return;
      var query = (inputEl.value || '').trim();
      if (!query) return;
      if (query.length > MAX_INPUT_CHARS) {
        showError(t(
          '单条问题最多 ' + MAX_INPUT_CHARS + ' 字，请精简后发送',
          'Maximum ' + MAX_INPUT_CHARS + ' characters per message — please shorten'
        ));
        return;
      }
      hideError();
      if (messages.length >= MAX_ROUNDS * 2) resetTopic(true);
      var apiMessage = buildContext(messages, query);
      messages.push({ role: 'user', content: query });
      appendUserBubble(query);
      persist();
      inputEl.value = '';
      inputEl.style.height = 'auto';
      setLoading(true);
      showTyping();
      postChat(apiMessage)
        .then(function (res) {
          var ui = createAssistantBubble();
          if (shouldUseStreamReader(res)) {
            return readStreamBody(res, ui).then(function (data) {
              messages.push({ role: 'assistant', content: data.reply, sources: data.sources || [] });
              persist();
              if (config.onReply) config.onReply(messages);
            });
          }
          return res.text().then(function (text) {
            hideTyping();
            var data = parseAggregatedText(text);
            finishReply(ui, data.reply, data.sources);
            messages.push({ role: 'assistant', content: data.reply, sources: data.sources || [] });
            persist();
            if (config.onReply) config.onReply(messages);
          });
        })
        .catch(function (err) {
          hideTyping();
          showError(err.message || t('发送失败，请重试', 'Failed to send — please retry'));
          messages.pop();
          persist();
          var last = messagesEl.querySelector('.sgt-tutor-msg.user:last-child');
          if (last) last.remove();
        })
        .finally(function () {
          setLoading(false);
          if (inputEl) inputEl.focus();
        });
    }

    function resetTopic(archive) {
      if (archive !== false && messages.length && config.onArchive) {
        config.onArchive(messages.slice());
      }
      messages = [];
      welcomed = false;
      if (messagesEl) messagesEl.innerHTML = '';
      hideError();
      if (!readOnly) showWelcome();
      persist();
      if (config.onReset) config.onReset();
    }

    function setMessages(msgs, opts) {
      messages = (msgs || []).slice();
      welcomed = false;
      renderAll();
      if (!(opts && opts.skipPersist)) persist();
    }

    function getMessages() {
      return messages.slice();
    }

    function bindInput() {
      if (!inputEl || readOnly) return;
      inputEl.setAttribute('maxlength', String(MAX_INPUT_CHARS));
      inputEl.placeholder = t(
        '输入问题（最多 500 字）',
        'Ask a question (max 500 chars)'
      );
      inputEl.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
      inputEl.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        updateCharCount();
        if (typeof config.onInputResize === 'function') config.onInputResize();
      });
      if (sendEl) sendEl.addEventListener('click', sendMessage);
      updateCharCount();
    }

    bindInput();
    renderAll();

    return {
      sendMessage: sendMessage,
      resetTopic: resetTopic,
      renderAll: renderAll,
      getMessages: getMessages,
      setMessages: setMessages,
      showWelcome: showWelcome,
      setReadOnly: function (ro) { readOnly = ro; setLoading(false); },
      setLoading: setLoading
    };
  }

  global.SgtAiEngine = {
    create: createChat,
    MAX_ROUNDS: 6,
    MAX_INPUT_CHARS: 500
  };
})(typeof window !== 'undefined' ? window : this);
