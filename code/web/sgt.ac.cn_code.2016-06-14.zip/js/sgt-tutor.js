/**
 * SGT AI 精灵 — 全站悬浮浮窗（依赖 SgtAiStore + SgtAiEngine）
 */
(function () {
  'use strict';

  var isOpen = false;
  var chat = null;
  var store = window.SgtAiStore;

  function $(sel) { return document.querySelector(sel); }

  function isEn() {
    return document.documentElement.classList.contains('lang-en');
  }

  function t(zh, en) { return isEn() ? en : zh; }

  function savePanelState(msgs) {
    if (!store) return;
    store.saveCurrent({ messages: msgs, isOpen: isOpen });
  }

  function togglePanel(force, skipSave) {
    isOpen = force != null ? force : !isOpen;
    var panel = $('#sgt-tutor-panel');
    var fab = $('#sgt-tutor-fab');
    if (panel) panel.classList.toggle('open', isOpen);
    if (fab) fab.classList.toggle('open', isOpen);
    if (fab) fab.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    if (isOpen) {
      if (chat && !chat.getMessages().length) chat.showWelcome();
      setTimeout(function () {
        var input = $('#sgt-tutor-input');
        if (input) input.focus();
      }, 200);
    }
    if (!skipSave && store) {
      store.saveCurrent({ messages: chat ? chat.getMessages() : [], isOpen: isOpen });
    }
  }

  function initChat() {
    if (!store || !window.SgtAiEngine) return null;
    var cur = store.getCurrent();
    return window.SgtAiEngine.create({
      messagesEl: '#sgt-tutor-messages',
      inputEl: '#sgt-tutor-input',
      sendBtnEl: '#sgt-tutor-send',
      errorEl: '#sgt-tutor-err',
      initialMessages: cur.messages,
      charCountEl: '#sgt-tutor-char-count',
      onPersist: savePanelState,
      onArchive: function (msgs) {
        store.archiveMessages(msgs, { startedAt: cur.ts });
      },
      onReset: function () {
        if (store) store.saveCurrent({ messages: [], isOpen: isOpen });
      }
    });
  }

  function init() {
    var fab = $('#sgt-tutor-fab');
    if (!fab) return;

    chat = initChat();

    fab.addEventListener('click', function () { togglePanel(); });
    $('#sgt-tutor-close').addEventListener('click', function () { togglePanel(false); });

    var newBtn = $('#sgt-tutor-new');
    if (newBtn) {
      newBtn.addEventListener('click', function () {
        if (chat) chat.resetTopic(true);
      });
      newBtn.title = t('归档当前对话并开始新话题', 'Archive chat and start new topic');
      newBtn.setAttribute('aria-label', newBtn.title);
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isOpen) togglePanel(false);
    });

    if (store) {
      var state = store.getCurrent();
      isOpen = !!state.isOpen;
      if (isOpen) togglePanel(true, true);
    }

    window.addEventListener('beforeunload', function () {
      if (store && chat) {
        store.saveCurrent({ messages: chat.getMessages(), isOpen: isOpen });
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
