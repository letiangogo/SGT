from PIL import Image

im = Image.open(r"d:\SGT\assets\sgt-logo.png").convert("RGBA")
w, h = im.size
left = im.crop((0, 0, int(w * 0.45), h))
pixels = left.load()
minx, miny, maxx, maxy = left.width, left.height, 0, 0
for y in range(left.height):
    for x in range(left.width):
        r, g, b, a = pixels[x, y]
        if r < 240 or g < 240 or b < 240:
            minx = min(minx, x)
            miny = min(miny, y)
            maxx = max(maxx, x)
            maxy = max(maxy, y)

cx = (minx + maxx) // 2
cy = (miny + maxy) // 2
size = max(maxx - minx, maxy - miny) + 48
x0 = max(0, cx - size // 2)
y0 = max(0, cy - size // 2)
x1 = min(left.width, x0 + size)
y1 = min(h, y0 + size)
icon = left.crop((x0, y0, x1, y1))
icon = icon.resize((256, 256), Image.LANCZOS)
icon.save(r"d:\SGT\assets\sgt-icon.png")

icon512 = icon.resize((512, 512), Image.LANCZOS)
icon512.save(
    r"d:\SGT\assets\favicon.ico",
    format="ICO",
    sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
)
print("OK:", minx, miny, maxx, maxy)
