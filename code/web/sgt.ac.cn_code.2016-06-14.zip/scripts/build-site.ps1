# Sync partials/site-header.html and site-footer.html into main-site HTML.
# Run from repo root:  powershell -File scripts/build-site.ps1

$Root = Split-Path -Parent $PSScriptRoot
$Partials = Join-Path $Root "partials"
$HeaderStart = "<!-- sgt:site-header -->"
$HeaderEnd = "<!-- /sgt:site-header -->"
$FooterStart = "<!-- sgt:site-footer -->"
$FooterEnd = "<!-- /sgt:site-footer -->"

$Pages = @(
    "index.html", "ai.html", "paper.html", "framework.html", "integrity.html",
    "predictions.html", "audit.html", "outlook.html", "copyright.html",
    "author.html", "zkav.html"
)

$NavPages = @(
    "index.html", "ai.html", "paper.html", "framework.html", "integrity.html",
    "predictions.html", "audit.html", "outlook.html", "copyright.html"
)

function Render-Partial($Name, $ActivePage) {
    $tpl = Get-Content (Join-Path $Partials $Name) -Raw -Encoding UTF8
    foreach ($p in $NavPages) {
        $key = "{{ACTIVE_$p}}"
        $repl = if ($p -eq $ActivePage) { ' class="active"' } else { "" }
        $tpl = $tpl.Replace($key, $repl)
    }
    return $tpl.Trim()
}

function Replace-Between($Content, $Start, $End, $Replacement) {
    $i = $Content.IndexOf($Start)
    $j = $Content.IndexOf($End)
    if ($i -lt 0 -or $j -lt 0 -or $j -lt $i) { return $Content }
    $j += $End.Length
    return $Content.Substring(0, $i + $Start.Length) + "`n" + $Replacement + "`n" + $Content.Substring($j)
}

function Ensure-FooterScripts($Content) {
    if ($Content -match "api-status\.js") { return $Content }
    $insert = '<script src="js/api-status.js"></script>' + "`n"
    if ($Content -match '<script src="js/main.js"></script>') {
        return $Content.Replace('<script src="js/main.js"></script>', $insert + '<script src="js/main.js"></script>', 1)
    }
    return $Content.Replace("</body>", $insert + "</body>", 1)
}

foreach ($page in $Pages) {
    $path = Join-Path $Root $page
    if (-not (Test-Path $path)) { Write-Host "skip $page"; continue }
    $text = Get-Content $path -Raw -Encoding UTF8
    $header = Render-Partial "site-header.html" $page
    $footer = Render-Partial "site-footer.html" $page

    if ($text.Contains($HeaderStart)) {
        $text = Replace-Between $text $HeaderStart $HeaderEnd $header
    }
    if ($text.Contains($FooterStart)) {
        $text = Replace-Between $text $FooterStart $FooterEnd $footer
    }

    $text = Ensure-FooterScripts $text
    [System.IO.File]::WriteAllText($path, $text, [System.Text.UTF8Encoding]::new($false))
    Write-Host "ok $page"
}

Write-Host "Done. Deploy root HTML only; do not upload 1/"
